// ═══════════════════════════════════════════════
// FilterSys — Add Activity Page + Analysis Engine
// ═══════════════════════════════════════════════

function initAddActivity() {
  const form = document.getElementById('add-activity-form');
  const user = loadUser();

  // Pre-fill GPA
  if (user) {
    document.getElementById('add-gpa-display').textContent =
      `${Number(user.currentGPA).toFixed(2)} → ${t('onboarding.targetGPALabel')}: ${Number(user.targetGPA).toFixed(2)}`;
  }


  // Set default date to today
  document.getElementById('add-date').value = new Date().toISOString().split('T')[0];

  // Render upcoming deadlines
  renderDeadlinesInForm();

  // Submit
  form.onsubmit = (e) => {
    e.preventDefault();


    const activity = {
      name: document.getElementById('add-name').value.trim(),
      category: document.getElementById('add-category').value,
      date: document.getElementById('add-date').value,
      time: document.getElementById('add-time').value,
      duration: parseFloat(document.getElementById('add-duration').value),
      location: document.getElementById('add-location').value.trim(),
      organizer: document.getElementById('add-organizer').value.trim(),
      description: document.getElementById('add-description').value.trim(),
      cost: parseInt(document.getElementById('add-cost').value) || 0,
      whyJoin: document.getElementById('add-why').value.trim(),
      whatGain: document.getElementById('add-gain').value.trim(),
      status: 'pending',
    };

    if (!activity.name || !activity.date || !activity.duration || !activity.whyJoin) {
      showToast(getLang() === 'vi' ? 'Điền đầy đủ các trường bắt buộc' : 'Fill in all required fields');
      return;
    }

    // Run analysis
    const analysis = analyzeActivity(activity, user);

    // Save temp
    const saved = addActivity({ ...activity, analysis });
    saveCurrentAnalysis({ activityId: saved.id, activity: saved, analysis });

    navigateTo('result');
  };
}

function renderDeadlinesInForm() {
  const container = document.getElementById('add-deadlines-list');
  const autoLabel = document.getElementById('add-deadlines-auto');
  const deadlines = getUpcomingDeadlines(7);

  autoLabel.textContent = t('addActivity.deadlinesAuto');

  if (deadlines.length === 0) {
    container.innerHTML = `<p class="text-muted text-sm">${t('addActivity.noDeadlines')}</p>`;
    return;
  }

  container.innerHTML = deadlines.map(d => {
    const typeLabels = {
      exam: t('dashboard.examLabel'),
      assignment: t('dashboard.assignmentLabel'),
      project: t('dashboard.projectLabel'),
      presentation: t('dashboard.presentationLabel'),
    };
    const typeClass = `badge-${d.type}`;

    return `
      <div class="deadline-item">
        <span class="academic-type-badge ${typeClass}">${typeLabels[d.type] || d.type}</span>
        <span class="deadline-item-name">${d.subject}${d.description ? ': ' + d.description : ''}</span>
        <span class="deadline-item-date">${formatDate(d.date)}</span>
      </div>
    `;
  }).join('');
}

// ═══════════════════════════════════════════════
// ANALYSIS ENGINE
// ═══════════════════════════════════════════════
// Methodology: Weighted multi-criteria decision analysis (MCDA)
// based on the Analytic Hierarchy Process (Saaty, 1980).
// Each dimension is scored 0–10, then combined via domain-
// informed weights. Verdict thresholds are calibrated so that
// a "balanced" activity with no red flags scores ~6.5.
// ═══════════════════════════════════════════════

function analyzeActivity(activity, user) {
  const scores = {};

  // 1. Goal Match (0–10) — MCDA alignment matrix
  scores.goalMatch = calcGoalMatch(activity, user);

  // 2. Energy Cost (0–10) — Spoon Theory + cognitive load
  scores.energyCost = calcEnergyCost(activity, user);

  // 3. Time Feasibility (0–10) — Budget utilization model
  scores.timeFeasibility = calcTimeFeasibility(activity, user);

  // 4. Pros vs Cons Balance (0–10) — Heuristic tally
  const prosConsList = generateProsCons(activity, user);
  scores.prosCons = prosConsList.score;

  // 5. Long-term Value (0–10) — Category + goal heuristic
  scores.longTermValue = calcLongTermValue(activity, user);

  // Weighted composite score (AHP-style weights)
  // Weights rationale: Goal alignment is weighted highest (30%)
  // because research shows value-congruent activities cause less
  // burnout (Maslach & Leiter, 1997). Time (25%) and Long-term
  // value (20%) are next. Energy (15%) and Pros/Cons (10%) are
  // supplementary signals.
  const totalScore = (
    scores.goalMatch * 0.3 +
    scores.energyCost * 0.15 +
    scores.timeFeasibility * 0.25 +
    scores.prosCons * 0.1 +
    scores.longTermValue * 0.2
  );

  let verdict;
  if (totalScore >= 6.5) verdict = 'recommended';
  else if (totalScore >= 4) verdict = 'risky';
  else verdict = 'skip';

  // Additional display-only analyses
  const opportunityCost = calcOpportunityCost(activity, user);
  const gpaRisk = calcGPARisk(activity, user);
  const energyBudget = calcEnergyBudget(activity, user);
  const goalAlignmentText = calcGoalAlignmentText(activity, user, scores.goalMatch);
  const examsNearby = getExamsWithinDays(3);
  const incompleteTasks = getIncompleteTasksThisWeek();

  return {
    scores,
    totalScore: Math.round(totalScore * 10) / 10,
    verdict,
    opportunityCost,
    gpaRisk,
    energyBudget,
    goalAlignmentText,
    pros: prosConsList.pros,
    cons: prosConsList.cons,
    examsNearby,
    incompleteTasks,
  };
}

// ─── 1. Goal Match ─────────────────────────────
// Methodology: Multi-criteria alignment matrix (MCDA).
// Each cell represents domain-expert judgment of how well
// an activity category serves a given priority. This is a
// standard approach in decision support systems.
function calcGoalMatch(activity, user) {
  const alignment = {
    academics: { networking: 2, workshop: 5, club: 3, volunteer: 2, competition: 6, hobby: 1, other: 2 },
    career: { networking: 9, workshop: 8, club: 5, volunteer: 6, competition: 7, hobby: 2, other: 3 },
    income: { networking: 6, workshop: 4, club: 2, volunteer: 1, competition: 3, hobby: 1, other: 2 },
    growth: { networking: 6, workshop: 7, club: 7, volunteer: 8, competition: 6, hobby: 9, other: 5 },
    balance: { networking: 6, workshop: 6, club: 6, volunteer: 6, competition: 6, hobby: 7, other: 5 },
  };

  const primary = user.primaryPriority || 'balance';
  const base = (alignment[primary] && alignment[primary][activity.category]) || 5;

  // Boost if secondary goals also align (+0.5 per aligned secondary)
  let boost = 0;
  (user.secondaryGoals || []).forEach(goal => {
    const secScore = (alignment[goal] && alignment[goal][activity.category]) || 5;
    if (secScore >= 7) boost += 0.5;
  });

  return Math.min(10, base + boost);
}

// ─── 2. Energy Cost ────────────────────────────
// Methodology: Adapted from Spoon Theory (Miserandino, 2003)
// and Kahneman's attention/cognitive load theory (2011).
// Energy is treated as a finite daily resource (1–10 scale).
// Drain rates are normalized to a 2-hour reference event at
// intensity 1.0. Category drain rates reflect the cognitive,
// physical, and emotional demands of each activity type.
//
// Drain rates:
//   Competition: 1.8 (high cognitive + performance anxiety)
//   Volunteer:   1.4 (physical + emotional labor)
//   Workshop:    1.3 (active learning, moderate cognitive load)
//   Networking:  1.2 (social energy expenditure)
//   Club:        1.0 (baseline social gathering)
//   Other:       1.0 (default baseline)
//   Hobby:       0.5 (restorative; Sonnentag, 2001 recovery research)
function calcEnergyCost(activity, user) {
  const duration = activity.duration || 1;
  const drainRates = {
    competition: 1.8,
    volunteer: 1.4,
    workshop: 1.3,
    networking: 1.2,
    club: 1.0,
    other: 1.0,
    hobby: 0.5,
  };
  const drainRate = drainRates[activity.category] || 1.0;

  // Normalized to 2-hour reference: a 2h club event drains 1.0 pts
  const energyDrain = (duration / 2) * drainRate;

  const baseline = user.energyBaseline || 7;
  const weekly = getWeeklyLog();
  const current = weekly.energyCurrent !== null ? weekly.energyCurrent : baseline;
  const remaining = Math.max(0, current - energyDrain);

  // Score: remaining energy mapped to 0–10
  return Math.min(10, Math.round(remaining));
}

// ─── 3. Time Feasibility ───────────────────────
// Methodology: Linear budget utilization model.
// Score = how much of your weekly extracurricular budget
// remains after this event.
//
// Formula: utilizationAfter = (usedHours + duration) / maxHours
// Score = max(1, round(10 × (1 - utilizationAfter)))
//
// Interpretation:
//   0% utilized → 10 (plenty of room)
//   50% utilized → 5
//   100% utilized → 1
//   >100% → 1 (over budget)
function calcTimeFeasibility(activity, user) {
  const weekly = getWeeklyLog();
  const maxHours = user.maxExtracurricularHours || 10;
  const used = weekly.hoursUsed || 0;
  const duration = activity.duration || 1;

  // Already over budget before this event
  if (used >= maxHours) return 1;

  const utilizationAfter = (used + duration) / maxHours;
  const score = Math.round(10 * (1 - utilizationAfter));
  return Math.max(1, Math.min(10, score));
}

// ─── 4. Long-term Value ────────────────────────
// Methodology: Category-based heuristic with secondary
// goal boosting. Reflects general career/development value
// of activity types based on employer surveys (NACE, 2023)
// and student development theory (Astin, 1984).
function calcLongTermValue(activity, user) {
  const catValue = {
    competition: 8,
    workshop: 7,
    networking: 6,
    volunteer: 7,
    club: 5,
    hobby: 4,
    other: 3,
  };
  let base = catValue[activity.category] || 5;

  const secondaryAlignment = {
    career: { competition: 2, workshop: 1, networking: 2 },
    growth: { volunteer: 1, hobby: 2, club: 1 },
    academics: { competition: 1, workshop: 1 },
  };
  (user.secondaryGoals || []).forEach(goal => {
    const boost = (secondaryAlignment[goal] && secondaryAlignment[goal][activity.category]) || 0;
    base += boost;
  });

  return Math.min(10, base);
}

// ─── 5. Pros & Cons ────────────────────────────
function generateProsCons(activity, user) {
  const pros = [];
  const cons = [];
  const lang = getLang();

  const duration = activity.duration || 1;
  const weekly = getWeeklyLog();
  const maxHours = user.maxExtracurricularHours || 10;
  const used = weekly.hoursUsed || 0;

  // Pros
  if (['networking', 'workshop'].includes(activity.category)) {
    pros.push(lang === 'vi' ? 'Mở rộng mạng lưới chuyên nghiệp' : 'Expand professional network');
  }
  if (['workshop', 'competition'].includes(activity.category)) {
    pros.push(lang === 'vi' ? 'Phát triển kỹ năng thiết thực' : 'Build practical skills');
  }
  if (activity.category === 'volunteer') {
    pros.push(lang === 'vi' ? 'Đóng góp xã hội & phát triển nhân cách' : 'Social contribution & character building');
  }
  if (activity.category === 'hobby') {
    pros.push(lang === 'vi' ? 'Thư giãn, phục hồi năng lượng' : 'Rest & energy recovery');
  }
  if (activity.category === 'competition') {
    pros.push(lang === 'vi' ? 'Nổi bật trong CV' : 'Stands out on resume');
  }
  if (activity.cost === 0) {
    pros.push(lang === 'vi' ? 'Miễn phí tham gia' : 'Free to attend');
  }
  if (activity.whatGain && activity.whatGain.length > 20) {
    pros.push(lang === 'vi' ? 'Bạn xác định rõ lợi ích cụ thể' : 'You identified specific benefits');
  }

  // Cons
  if (duration >= 3) {
    cons.push(lang === 'vi' ? `Chiếm ${duration} giờ liên tục` : `Takes ${duration} consecutive hours`);
  }
  if (used + duration > maxHours) {
    cons.push(lang === 'vi' ? 'Vượt ngân sách giờ ngoại khóa tuần này' : 'Exceeds weekly extracurricular budget');
  }

  const exams = getExamsWithinDays(3);
  if (exams.length > 0) {
    const examNames = exams.map(e => e.subject).join(', ');
    cons.push(lang === 'vi' ? `Gần kỳ thi: ${examNames}` : `Near exam: ${examNames}`);
  }

  const incomplete = getIncompleteTasksThisWeek();
  if (incomplete.length >= 2) {
    cons.push(lang === 'vi' ? `${incomplete.length} bài tập chưa hoàn thành` : `${incomplete.length} unfinished assignments`);
  }

  if (activity.cost > 0) {
    cons.push(lang === 'vi' ? `Chi phí: ${activity.cost.toLocaleString()} VND` : `Cost: ${activity.cost.toLocaleString()} VND`);
  }

  const goalScore = calcGoalMatch(activity, user);
  if (goalScore <= 4) {
    const priLabels = {
      academics: lang === 'vi' ? 'tập trung học tập' : 'academic focus',
      career: lang === 'vi' ? 'phát triển nghề nghiệp' : 'career building',
      income: lang === 'vi' ? 'kiếm thu nhập' : 'earning income',
      growth: lang === 'vi' ? 'phát triển bản thân' : 'personal growth',
      balance: lang === 'vi' ? 'cân bằng' : 'balanced lifestyle',
    };
    cons.push(lang === 'vi'
      ? `Ít phù hợp với mục tiêu: ${priLabels[user.primaryPriority]}`
      : `Low alignment with priority: ${priLabels[user.primaryPriority]}`
    );
  }

  // Detect FOMO in reason
  const fomoKeywords = ['everyone', 'mọi người', 'ai cũng', 'bỏ lỡ', 'missing out', 'left out', 'fomo', 'peer'];
  const whyLower = (activity.whyJoin || '').toLowerCase();
  if (fomoKeywords.some(kw => whyLower.includes(kw))) {
    cons.push(lang === 'vi'
      ? '⚠️ Lý do tham gia có dấu hiệu FOMO — hãy xem xét lại'
      : '⚠️ Your reason shows signs of FOMO — reconsider carefully'
    );
  }

  const score = Math.min(10, Math.max(1, 5 + pros.length - cons.length));
  return { pros, cons, score };
}

// ─── Display: Opportunity Cost ─────────────────
// Methodology: Direct time substitution (Economics 101).
// 1 hour spent at an event = 1 hour you cannot study.
// This is definitionally true — the "next best alternative
// forgone" (Mankiw, Principles of Economics).
//
// Pomodoro conversion: Cirillo (2006) The Pomodoro Technique.
// One productive cycle = ~45 min (25 min focus + 5 min break
// + ~15 min setup/context-switching overhead per Ariga &
// Lleras, 2011).
function calcOpportunityCost(activity, user) {
  const duration = activity.duration || 1;
  const subjects = user.keySubjects || [];

  // 1:1 direct substitution
  const lostStudyHours = duration;

  // Convert to Pomodoro-equivalent productive cycles
  // 1 Pomodoro cycle ≈ 45 min (0.75 hours) of wall-clock time
  const pomodoroSessions = Math.round((lostStudyHours / 0.75) * 10) / 10;

  const lang = getLang();
  const subjectExample = subjects[0] || (lang === 'vi' ? 'môn học chính' : 'your key subject');

  return {
    duration,
    pomodoroSessions,
    subjectExample,
    text: lang === 'vi'
      ? `${duration} giờ sự kiện = ${duration} giờ không thể học. Tương đương ~${pomodoroSessions} chu kỳ Pomodoro (45 phút/chu kỳ) cho ${subjectExample}.`
      : `${duration}h at this event = ${duration}h you can't study. That's ~${pomodoroSessions} Pomodoro cycles (45 min each) for ${subjectExample}.`,
  };
}

// ─── Display: GPA Risk ─────────────────────────
// Methodology: Percentage-of-budget model.
// Study time reduction = duration / weeklyStudyHours × 100
// (straightforward: what % of your study plan does this consume?)
//
// Risk thresholds informed by:
// - Credé et al. (2010) meta-analysis: study habits explain
//   ~16% of GPA variance; consistent time reduction compounds.
// - Auburn University: "over-involved" = 11+ hrs/week of
//   extracurriculars correlates with burnout.
//
// Risk levels:
//   LOW:      reduction < 10% AND gapGPA ≤ 0.3
//   MODERATE: reduction 10–20% OR gapGPA > 0.3
//   HIGH:     reduction > 20% AND gapGPA > 0.3, OR reduction > 30%
// Exam proximity: if exam within 3 days, risk escalates one level.
function calcGPARisk(activity, user) {
  const duration = activity.duration || 1;
  const studyHours = user.studyHoursWeekly || 20;

  // Direct percentage: how much of weekly study time does this event consume?
  const reductionPct = Math.round((duration / studyHours) * 100);

  const gapGPA = user.targetGPA - user.currentGPA;

  // Determine base risk level
  let riskLevel;
  if (reductionPct > 30) {
    riskLevel = 'high';
  } else if (reductionPct > 20 && gapGPA > 0.3) {
    riskLevel = 'high';
  } else if (reductionPct > 10 || gapGPA > 0.3) {
    riskLevel = 'moderate';
  } else {
    riskLevel = 'low';
  }

  // Exam proximity escalation
  const lang = getLang();
  const exams = getExamsWithinDays(3);
  let examWarning = '';
  if (exams.length > 0) {
    // Escalate risk one level
    if (riskLevel === 'low') riskLevel = 'moderate';
    else if (riskLevel === 'moderate') riskLevel = 'high';

    examWarning = lang === 'vi'
      ? ` ⚠️ ${t('result.examWarning')}: ${exams.map(e => e.subject).join(', ')}.`
      : ` ⚠️ ${t('result.examWarning')}: ${exams.map(e => e.subject).join(', ')}.`;
  }

  const incomplete = getIncompleteTasksThisWeek();
  let taskWarning = '';
  if (incomplete.length > 0) {
    taskWarning = lang === 'vi'
      ? ` ${incomplete.length} ${t('result.homeworkWarning')}.`
      : ` ${incomplete.length} ${t('result.homeworkWarning')}.`;
  }

  return {
    reductionPct,
    riskLevel,
    text: lang === 'vi'
      ? `Sự kiện ${duration}h chiếm ${reductionPct}% thời gian tự học hàng tuần (${studyHours}h). Với GPA ${Number(user.currentGPA).toFixed(2)} → mục tiêu ${Number(user.targetGPA).toFixed(2)}, rủi ro ở mức ${riskLevel === 'high' ? 'CAO' : riskLevel === 'moderate' ? 'TRUNG BÌNH' : 'THẤP'}.${examWarning}${taskWarning}`
      : `This ${duration}h event uses ${reductionPct}% of your ${studyHours}h weekly study budget. With GPA ${Number(user.currentGPA).toFixed(2)} → target ${Number(user.targetGPA).toFixed(2)}, the risk is ${riskLevel.toUpperCase()}.${examWarning}${taskWarning}`,
  };
}

// ─── Display: Energy Budget ────────────────────
// Uses the same drain model as calcEnergyCost above.
function calcEnergyBudget(activity, user) {
  const baseline = user.energyBaseline || 7;
  const weekly = getWeeklyLog();
  const current = weekly.energyCurrent !== null ? weekly.energyCurrent : baseline;
  const duration = activity.duration || 1;

  const drainRates = {
    competition: 1.8, volunteer: 1.4, workshop: 1.3,
    networking: 1.2, club: 1.0, other: 1.0, hobby: 0.5,
  };
  const drainRate = drainRates[activity.category] || 1.0;
  const energyDrain = Math.round(((duration / 2) * drainRate) * 10) / 10;
  const remaining = Math.round(Math.max(0, current - energyDrain) * 10) / 10;

  const catDescriptions = {
    competition: { en: 'high cognitive load', vi: 'tải nhận thức cao' },
    volunteer: { en: 'physical + emotional effort', vi: 'thể chất + cảm xúc' },
    workshop: { en: 'active learning', vi: 'học tập chủ động' },
    networking: { en: 'social energy', vi: 'năng lượng xã hội' },
    club: { en: 'social gathering', vi: 'giao lưu nhóm' },
    hobby: { en: 'restorative activity', vi: 'hoạt động phục hồi' },
    other: { en: 'general activity', vi: 'hoạt động chung' },
  };
  const desc = catDescriptions[activity.category] || catDescriptions.other;

  const lang = getLang();
  return {
    current,
    energyDrain,
    remaining,
    text: lang === 'vi'
      ? `Năng lượng: ${current}/10. Sự kiện ${duration}h (${desc.vi}) tiêu tốn ~${energyDrain} điểm. Còn lại: ~${remaining}/10.`
      : `Energy: ${current}/10. This ${duration}h event (${desc.en}) drains ~${energyDrain} pts. Remaining: ~${remaining}/10.`,
  };
}

// ─── Display: Goal Alignment ───────────────────
function calcGoalAlignmentText(activity, user, score) {
  const lang = getLang();
  const priLabels = {
    academics: lang === 'vi' ? 'Tập trung vào học tập' : 'Focus on academics',
    career: lang === 'vi' ? 'Phát triển kỹ năng nghề nghiệp' : 'Build career skills',
    income: lang === 'vi' ? 'Kiếm thu nhập hỗ trợ gia đình' : 'Earn income to support family',
    growth: lang === 'vi' ? 'Khám phá sở thích & phát triển bản thân' : 'Explore interests & personal growth',
    balance: lang === 'vi' ? 'Cân bằng mọi thứ' : 'Balance everything equally',
  };

  let alignment;
  if (score >= 7) alignment = t('result.alignmentHigh');
  else if (score >= 4) alignment = t('result.alignmentMed');
  else alignment = t('result.alignmentLow');

  const catLabels = {
    networking: lang === 'vi' ? 'giao lưu, mở rộng mối quan hệ' : 'networking',
    workshop: lang === 'vi' ? 'hội thảo kỹ năng' : 'skills workshop',
    club: lang === 'vi' ? 'sự kiện câu lạc bộ' : 'club event',
    volunteer: lang === 'vi' ? 'tình nguyện' : 'volunteering',
    competition: lang === 'vi' ? 'cuộc thi' : 'competition',
    hobby: lang === 'vi' ? 'sở thích' : 'hobby',
    other: lang === 'vi' ? 'khác' : 'other',
  };

  return lang === 'vi'
    ? `${t('result.primaryPriority')}: ${priLabels[user.primaryPriority]}. Hoạt động "${catLabels[activity.category]}" có ${alignment} với mục tiêu này.`
    : `${t('result.primaryPriority')}: ${priLabels[user.primaryPriority]}. This "${catLabels[activity.category]}" event has ${alignment} with that goal.`;
}

function renderAddActivityText() {
  document.getElementById('add-title').textContent = t('addActivity.title');
  document.getElementById('add-event-section').textContent = t('addActivity.eventSection');
  document.getElementById('add-lbl-name').textContent = t('addActivity.nameLabel');
  document.getElementById('add-name').placeholder = t('addActivity.namePlaceholder');
  document.getElementById('add-lbl-category').textContent = t('addActivity.categoryLabel');
  document.getElementById('add-cat-networking').textContent = t('addActivity.catNetworking');
  document.getElementById('add-cat-workshop').textContent = t('addActivity.catWorkshop');
  document.getElementById('add-cat-club').textContent = t('addActivity.catClub');
  document.getElementById('add-cat-volunteer').textContent = t('addActivity.catVolunteer');
  document.getElementById('add-cat-competition').textContent = t('addActivity.catCompetition');
  document.getElementById('add-cat-hobby').textContent = t('addActivity.catHobby');
  document.getElementById('add-cat-other').textContent = t('addActivity.catOther');
  document.getElementById('add-lbl-date').textContent = t('addActivity.dateLabel');
  document.getElementById('add-lbl-time').textContent = t('addActivity.timeLabel');
  document.getElementById('add-lbl-duration').textContent = t('addActivity.durationLabel');
  document.getElementById('add-lbl-location').textContent = t('addActivity.locationLabel');
  document.getElementById('add-location').placeholder = t('addActivity.locationPlaceholder');
  document.getElementById('add-lbl-organizer').textContent = t('addActivity.organizerLabel');
  document.getElementById('add-org-placeholder').textContent = t('addActivity.orgPlaceholder');
  document.getElementById('add-org-ftu').textContent = t('addActivity.orgFTU');
  document.getElementById('add-org-ext-cert').textContent = t('addActivity.orgExtCert');
  document.getElementById('add-org-ext-nocert').textContent = t('addActivity.orgExtNoCert');
  document.getElementById('add-org-other').textContent = t('addActivity.orgOther');
  document.getElementById('add-lbl-description').textContent = t('addActivity.descriptionLabel');
  document.getElementById('add-description').placeholder = t('addActivity.descriptionPlaceholder');
  document.getElementById('add-lbl-cost').textContent = t('addActivity.costLabel');
  document.getElementById('add-cost').placeholder = t('addActivity.costPlaceholder');
  document.getElementById('add-personal-section').textContent = t('addActivity.personalSection');
  document.getElementById('add-lbl-why').textContent = t('addActivity.whyLabel');
  document.getElementById('add-why').placeholder = t('addActivity.whyPlaceholder');
  document.getElementById('add-lbl-gain').textContent = t('addActivity.gainLabel');
  document.getElementById('add-gain').placeholder = t('addActivity.gainPlaceholder');
  document.getElementById('add-lbl-gpa').textContent = t('addActivity.gpaStatus');
  document.getElementById('add-lbl-deadlines').textContent = t('addActivity.deadlinesLabel');
  document.getElementById('btn-analyze').textContent = t('addActivity.analyze');

}


