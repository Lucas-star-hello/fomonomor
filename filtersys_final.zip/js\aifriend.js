// ═══════════════════════════════════════════════
// FilterSys — AI Friend Chat
// ═══════════════════════════════════════════════

function initAIFriend() {
  const chat = document.getElementById('ai-chat');
  const input = document.getElementById('ai-input');
  const sendBtn = document.getElementById('btn-ai-send');
  const suggestList = document.getElementById('ai-suggest-list');

  // Clear previous chat
  chat.innerHTML = '';

  // Welcome message
  const lang = getLang();
  const user = loadUser();
  const alias = user ? user.alias : '';
  const welcome = lang === 'vi'
    ? `Chào${alias ? ' ' + alias : ''}. Tôi không phán xét — tôi chỉ dựa trên dữ liệu và phản hồi thẳng thắn. Bạn đang suy nghĩ về điều gì?`
    : `Hey${alias ? ' ' + alias : ''}. No judgment here — just data and honest feedback. What's on your mind?`;

  chat.innerHTML = `<div class="chat-bubble chat-bubble--ai">${welcome}</div>`;

  // Render suggestion pills
  const suggestions = t('aiFriend.suggestions');
  if (Array.isArray(suggestions)) {
    suggestList.innerHTML = suggestions.map(s =>
      `<button class="suggest-pill">${s}</button>`
    ).join('');

    suggestList.querySelectorAll('.suggest-pill').forEach(pill => {
      pill.addEventListener('click', () => {
        input.value = pill.textContent;
        sendAIMessage();
      });
    });
  }

  // Send
  sendBtn.onclick = sendAIMessage;
  input.onkeydown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendAIMessage();
    }
  };
}

function sendAIMessage() {
  const chat = document.getElementById('ai-chat');
  const input = document.getElementById('ai-input');
  const text = input.value.trim();
  if (!text) return;

  const user = loadUser();
  const lang = getLang();

  // Hide suggestions after first message
  document.getElementById('ai-suggestions').style.display = 'none';

  // User bubble
  chat.innerHTML += `<div class="chat-bubble chat-bubble--user">${escapeHtml(text)}</div>`;
  input.value = '';

  // AI response
  setTimeout(() => {
    const response = generateAIResponse(text, user, lang);
    chat.innerHTML += `<div class="chat-bubble chat-bubble--ai">${response}</div>`;
    chat.scrollTop = chat.scrollHeight;
  }, 600);

  chat.scrollTop = chat.scrollHeight;
}

function generateAIResponse(userText, user, lang) {
  const textLower = userText.toLowerCase();
  const weekly = getWeeklyLog();
  const committed = getCommittedActivities();
  const maxHours = user ? user.maxExtracurricularHours : 10;
  const hoursUsed = weekly.hoursUsed || 0;
  const energy = weekly.energyCurrent !== null ? weekly.energyCurrent : (user ? user.energyBaseline : 7);
  const exams = getExamsWithinDays(7);
  const incomplete = getIncompleteTasksThisWeek();
  const remaining = maxHours - hoursUsed;

  // Detect intent
  const isFOMO = /fomo|bỏ lỡ|missing|left out|mọi người|everyone|ai cũng đi|tất cả/i.test(textLower);
  const isOvercommit = /too many|quá nhiều|overwhelm|nhiều quá|busy|bận/i.test(textLower);
  const isQuit = /quit|rời|leave|bỏ|drop|nghỉ|thôi/i.test(textLower);
  const isGuilty = /guilt|tội|có lỗi|feel bad|áy náy|xấu hổ/i.test(textLower);
  const isConfused = /don't know|không biết|confused|phân vân|uncertain|lưỡng lự|không chắc/i.test(textLower);
  const isTime = /time|thời gian|giờ|hour|schedule|lịch/i.test(textLower);

  // Build data context
  const dataBlock = lang === 'vi'
    ? `\n\n📊 <em>Dữ liệu tuần này: ${hoursUsed}/${maxHours}h ngoại khóa, năng lượng ${energy}/10, ${committed.length} hoạt động, ${exams.length} kỳ thi sắp tới, ${incomplete.length} bài chưa xong.</em>`
    : `\n\n📊 <em>This week: ${hoursUsed}/${maxHours}h extracurriculars, energy ${energy}/10, ${committed.length} activities, ${exams.length} exams ahead, ${incomplete.length} tasks pending.</em>`;

  if (isFOMO) {
    return lang === 'vi'
      ? `Cảm giác bỏ lỡ là phản ứng tự nhiên — nhưng đó không phải lý do đủ tốt để cam kết thời gian.<br><br>Hãy tự hỏi:<br>• Nếu không ai đăng bài về sự kiện này, bạn có vẫn muốn đi?<br>• Bạn sẽ nhớ gì về sự kiện này sau 1 tháng?<br>• Thời gian đó có thể dùng cho mục tiêu ưu tiên (${getPriorityLabel(user, lang)}) không?<br><br>58% sinh viên trải qua FOMO mức trung bình-cao. Bạn không đơn độc — nhưng bạn cũng không bắt buộc phải theo đám đông.${dataBlock}`
      : `Feeling left out is a natural reaction — but it's not a good enough reason to commit your time.<br><br>Ask yourself:<br>• If nobody posted about this event, would you still want to go?<br>• What will you remember about this event in a month?<br>• Could that time go toward your priority (${getPriorityLabel(user, lang)})?<br><br>58% of students experience moderate-to-high FOMO. You're not alone — but you're also not obligated to follow the crowd.${dataBlock}`;
  }

  if (isOvercommit) {
    const overBy = hoursUsed - maxHours;
    return lang === 'vi'
      ? `Dữ liệu nói rõ: bạn đã dùng ${hoursUsed}h trong ngân sách ${maxHours}h.${overBy > 0 ? ` Vượt ${overBy}h — tức ${Math.round(overBy / maxHours * 100)}% quá tải.` : ''}<br><br>${committed.length > 0 ? `Bạn có ${committed.length} hoạt động đã cam kết. ` : ''}${incomplete.length > 0 ? `Còn ${incomplete.length} bài tập chưa xong. ` : ''}<br><br><strong>Gợi ý cụ thể:</strong> Xếp hạng các cam kết theo mức ưu tiên. Cân nhắc bỏ hoạt động có ưu tiên thấp nhất. Bạn đã tự đặt giới hạn ${maxHours}h — hãy tôn trọng giới hạn của chính mình.${dataBlock}`
      : `The data is clear: you've used ${hoursUsed}h of your ${maxHours}h budget.${overBy > 0 ? ` That's ${overBy}h over — ${Math.round(overBy / maxHours * 100)}% overloaded.` : ''}<br><br>${committed.length > 0 ? `You have ${committed.length} committed activities. ` : ''}${incomplete.length > 0 ? `${incomplete.length} tasks still pending. ` : ''}<br><br><strong>Concrete suggestion:</strong> Rank your commitments by priority. Consider dropping the lowest one. You set a ${maxHours}h limit for a reason — respect your own boundaries.${dataBlock}`;
  }

  if (isQuit) {
    return lang === 'vi'
      ? `Bỏ một hoạt động không phải thất bại — đó là phân bổ lại nguồn lực.<br><br>Trước khi quyết định, hãy xem:<br>• Hoạt động này có phù hợp với mục tiêu chính (${getPriorityLabel(user, lang)}) không?<br>• Bạn có học/nhận được gì có giá trị trong 3 tuần gần nhất không?<br>• Nếu bỏ, bạn sẽ dùng thời gian đó cho việc gì cụ thể?<br><br>Nếu câu trả lời cho 2 câu đầu là "không" và bạn có kế hoạch rõ cho câu 3, thì bỏ là quyết định đúng.${dataBlock}`
      : `Quitting isn't failure — it's resource reallocation.<br><br>Before you decide, consider:<br>• Does this activity align with your primary goal (${getPriorityLabel(user, lang)})?<br>• Have you learned anything valuable in the last 3 weeks?<br>• If you quit, what specifically will you do with that time?<br><br>If the answer to the first two is "no" and you have a clear plan for the third, quitting is the right call.${dataBlock}`;
  }

  if (isGuilty) {
    return lang === 'vi'
      ? `Cảm giác có lỗi khi từ chối là phổ biến — nhưng không có nghĩa là bạn sai.<br><br>Sự thật: mỗi lần nói "có" với một thứ là nói "không" với thứ khác. Khi bạn nói "có" với sự kiện 3 giờ, bạn đang nói "không" với 3 giờ tự học, nghỉ ngơi, hoặc mục tiêu cá nhân.<br><br>Bạn có ${remaining}h còn lại tuần này. ${energy <= 4 ? 'Và năng lượng đang ở mức thấp. ' : ''}Ưu tiên bản thân không phải ích kỷ — đó là quản lý nguồn lực.${dataBlock}`
      : `Feeling guilty about saying no is common — but it doesn't mean you're wrong.<br><br>The truth: every "yes" is a "no" to something else. When you say "yes" to a 3-hour event, you're saying "no" to 3 hours of studying, resting, or pursuing your personal goals.<br><br>You have ${remaining}h left this week. ${energy <= 4 ? 'And your energy is running low. ' : ''}Prioritizing yourself isn't selfish — it's resource management.${dataBlock}`;
  }

  if (isConfused) {
    return lang === 'vi'
      ? `Khi không chắc chắn, hãy dùng dữ liệu thay vì cảm xúc.<br><br>Đây là tình trạng hiện tại của bạn:<br>• Ngân sách: ${hoursUsed}/${maxHours}h (còn ${remaining}h)<br>• Năng lượng: ${energy}/10<br>• Ưu tiên chính: ${getPriorityLabel(user, lang)}<br>${exams.length > 0 ? `• Kỳ thi sắp tới: ${exams.map(e => e.subject).join(', ')}\n` : ''}${incomplete.length > 0 ? `• Bài tập chưa xong: ${incomplete.length}\n` : ''}<br><br>Hãy thử thêm hoạt động cụ thể vào mục "Thêm hoạt động" — hệ thống sẽ phân tích chi tiết dựa trên tình trạng thực tế của bạn.`
      : `When you're unsure, use data instead of feelings.<br><br>Here's your current status:<br>• Budget: ${hoursUsed}/${maxHours}h (${remaining}h remaining)<br>• Energy: ${energy}/10<br>• Primary priority: ${getPriorityLabel(user, lang)}<br>${exams.length > 0 ? `• Upcoming exams: ${exams.map(e => e.subject).join(', ')}\n` : ''}${incomplete.length > 0 ? `• Pending tasks: ${incomplete.length}\n` : ''}<br><br>Try adding the specific activity in "Add Activity" — the system will analyze it based on your actual situation.`;
  }

  // Default / general response
  return lang === 'vi'
    ? `Cảm ơn bạn đã chia sẻ. Dựa trên dữ liệu hiện tại:<br><br>• Bạn đã dùng ${hoursUsed} trong ${maxHours}h ngoại khóa tuần này<br>• Năng lượng: ${energy}/10<br>${exams.length > 0 ? `• ${exams.length} kỳ thi sắp tới<br>` : ''}${incomplete.length > 0 ? `• ${incomplete.length} bài tập chưa hoàn thành<br>` : ''}<br>Nếu bạn đang cân nhắc một hoạt động cụ thể, hãy thử thêm nó vào "Thêm hoạt động" để nhận phân tích chi tiết. Hoặc mô tả cụ thể hơn tình huống của bạn — tôi sẽ đưa ra phản hồi dựa trên dữ liệu.${dataBlock}`
    : `Thanks for sharing. Based on your current data:<br><br>• ${hoursUsed} of ${maxHours}h extracurricular budget used this week<br>• Energy: ${energy}/10<br>${exams.length > 0 ? `• ${exams.length} exam(s) coming up<br>` : ''}${incomplete.length > 0 ? `• ${incomplete.length} pending task(s)<br>` : ''}<br>If you're weighing a specific activity, try adding it in "Add Activity" for a detailed breakdown. Or describe your situation more specifically — I'll give you a data-backed response.${dataBlock}`;
}

function getPriorityLabel(user, lang) {
  if (!user) return '';
  const labels = {
    academics: lang === 'vi' ? 'tập trung học tập' : 'academic focus',
    career: lang === 'vi' ? 'phát triển nghề nghiệp' : 'career building',
    income: lang === 'vi' ? 'kiếm thu nhập hỗ trợ gia đình' : 'earning income to support family',
    growth: lang === 'vi' ? 'phát triển bản thân' : 'personal growth',
    balance: lang === 'vi' ? 'cân bằng mọi thứ' : 'balanced lifestyle',
  };
  return labels[user.primaryPriority] || '';
}

function renderAIFriendText() {
  document.getElementById('ai-title').textContent = t('aiFriend.title');
  document.getElementById('ai-subtitle').textContent = t('aiFriend.subtitle');
  document.getElementById('ai-input').placeholder = t('aiFriend.inputPlaceholder');
  document.getElementById('btn-ai-send').textContent = t('aiFriend.send');
  document.getElementById('ai-suggest-label').textContent = t('aiFriend.suggestLabel');
}
