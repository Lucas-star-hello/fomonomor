// ═══════════════════════════════════════════════
// FilterSys — Main App (Router + Init)
// ═══════════════════════════════════════════════

const PAGES = ['landing', 'quiz', 'onboarding', 'dashboard', 'add-activity', 'result', 'mentor', 'ai-friend', 'gpa'];
let currentPage = 'landing';

// ─── Navigation ───

function navigateTo(page) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));

  // Show target
  const target = document.getElementById(`page-${page}`);
  if (target) {
    target.classList.add('active');
    // Re-trigger animation
    target.style.animation = 'none';
    target.offsetHeight; // reflow
    target.style.animation = '';
  }

  currentPage = page;

  // Header visibility
  const header = document.getElementById('global-header');
  if (page === 'landing') {
    header.classList.add('hidden');
  } else {
    header.classList.remove('hidden');
  }

  // Back button visibility
  const backBtn = document.getElementById('header-back');
  if (['dashboard'].includes(page)) {
    backBtn.style.visibility = 'hidden';
  } else {
    backBtn.style.visibility = 'visible';
  }

  // Update text for current page
  updatePageText();

  // Page-specific init
  switch (page) {
    case 'quiz':
      initQuiz();
      break;
    case 'onboarding':
      initOnboarding();
      break;
    case 'dashboard':
      initDashboard();
      break;
    case 'add-activity':
      initAddActivity();
      break;
    case 'result':
      initResult();
      break;
    case 'mentor':
      initMentor();
      break;
    case 'ai-friend':
      initAIFriend();
      break;
    case 'gpa':
      initGPA();
      break;
  }

  // Scroll to top
  window.scrollTo(0, 0);
}

// ─── Back navigation ───

function getBackPage() {
  const backMap = {
    'quiz': 'landing',
    'onboarding': hasUser() ? 'dashboard' : 'quiz',
    'add-activity': 'dashboard',
    'result': 'dashboard',
    'mentor': 'dashboard',
    'ai-friend': 'dashboard',
    'gpa': 'dashboard',
  };
  return backMap[currentPage] || 'dashboard';
}

// ─── Language ───

function toggleLanguage() {
  const current = getLang();
  const next = current === 'en' ? 'vi' : 'en';
  setLang(next);
  updateAllText();
}

function updateAllText() {
  // Landing
  renderLandingText();
  // Quiz
  renderQuizText();
  // Onboarding
  renderOnboardingText();
  // Dashboard
  renderDashboardText();
  // Add Activity
  renderAddActivityText();
  // Result
  renderResultText();
  // Mentor
  renderMentorText();
  // AI Friend
  renderAIFriendText();
  // GPA
  if (typeof renderGPAText === 'function') renderGPAText();

  // Lang toggle buttons
  const langLabel = t('common.langToggle');
  document.getElementById('lang-toggle').textContent = langLabel;
  document.getElementById('landing-lang-toggle').textContent = getLang() === 'en' ? 'VN' : 'EN';

  // Header title
  document.getElementById('header-title').textContent = t('common.appName');
}

function updatePageText() {
  updateAllText();
}

// ─── Landing Page ───

function renderLandingText() {
  document.getElementById('landing-tagline').textContent = t('landing.tagline');
  document.getElementById('landing-desc').textContent = t('landing.desc');
  document.getElementById('landing-cta').textContent = t('landing.cta');

  document.getElementById('stat1val').textContent = t('landing.stat1val');
  document.getElementById('stat1desc').textContent = t('landing.stat1');
  document.getElementById('stat2val').textContent = t('landing.stat2val');
  document.getElementById('stat2desc').textContent = t('landing.stat2');
  document.getElementById('stat3val').textContent = t('landing.stat3val');
  document.getElementById('stat3desc').textContent = t('landing.stat3');
  document.getElementById('stat4val').textContent = t('landing.stat4val');
  document.getElementById('stat4desc').textContent = t('landing.stat4');

  document.getElementById('refs-label').textContent = t('landing.refLabel');
  document.getElementById('ref1').textContent = t('landing.ref1');
  document.getElementById('ref2').textContent = t('landing.ref2');
  document.getElementById('ref3').textContent = t('landing.ref3');
  document.getElementById('ref4').textContent = t('landing.ref4');
}

// ─── Stat card animations ───

function animateStatCards() {
  const cards = document.querySelectorAll('.stat-card');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const delay = parseInt(entry.target.dataset.delay) || 0;
        setTimeout(() => {
          entry.target.classList.add('visible');
        }, delay);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });

  cards.forEach(card => observer.observe(card));
}

// ─── Toast ───

function showToast(message, duration = 3000) {
  const toast = document.getElementById('toast');
  const text = document.getElementById('toast-text');
  text.textContent = message;
  toast.classList.remove('hidden');
  toast.style.animation = 'none';
  toast.offsetHeight;
  toast.style.animation = '';

  setTimeout(() => {
    toast.classList.add('hidden');
  }, duration);
}

// ─── Confirm Dialog ───

function showConfirmDialog(message, onConfirm) {
  const dialog = document.getElementById('dialog-confirm');
  const msgEl = document.getElementById('confirm-msg');
  const cancelBtn = document.getElementById('btn-confirm-cancel');
  const okBtn = document.getElementById('btn-confirm-ok');

  msgEl.textContent = message;
  cancelBtn.textContent = t('dashboard.removeCancel');
  okBtn.textContent = t('dashboard.removeOk');

  dialog.classList.remove('hidden');

  const closeDialog = () => {
    dialog.classList.add('hidden');
    cancelBtn.removeEventListener('click', handleCancel);
    okBtn.removeEventListener('click', handleOk);
  };

  const handleCancel = () => closeDialog();
  const handleOk = () => {
    closeDialog();
    if (onConfirm) onConfirm();
  };

  cancelBtn.addEventListener('click', handleCancel);
  okBtn.addEventListener('click', handleOk);
}

// ─── Init ───

document.addEventListener('DOMContentLoaded', () => {
  // Set initial language
  if (!localStorage.getItem('fs_lang')) {
    setLang('en');
  }

  // Render all text
  updateAllText();

  // Landing page stat animations
  animateStatCards();

  // Init academic modal
  initAcademicModal();

  document.getElementById('landing-cta').addEventListener('click', () => {
    if (hasUser()) {
      navigateTo('dashboard');
    } else {
      navigateTo('quiz');
    }
  });

  // Language toggles
  document.getElementById('landing-lang-toggle').addEventListener('click', toggleLanguage);
  document.getElementById('lang-toggle').addEventListener('click', toggleLanguage);

  // Back button
  document.getElementById('header-back').addEventListener('click', () => {
    navigateTo(getBackPage());
  });

  // Auto-navigate if user exists
  if (hasUser()) {
    navigateTo('dashboard');
  }
});
