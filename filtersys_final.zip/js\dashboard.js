// ═══════════════════════════════════════════════
// FilterSys — Dashboard Page
// ═══════════════════════════════════════════════

function initDashboard() {
  const user = loadUser();
  if (!user) return;

  recalcWeeklyLog();
  renderDashboardGreeting(user);
  renderStatusBars(user);
  renderWeekCalendar();
  renderCommittedActivities();
  renderAcademicChecklist();
  renderMotivationBoard();
  bindDashboardActions();
  initMotivationModal();
}

function renderDashboardGreeting(user) {
  const hour = new Date().getHours();
  let greeting;
  if (hour < 12) greeting = t('dashboard.greetingMorning');
  else if (hour < 18) greeting = t('dashboard.greetingAfternoon');
  else greeting = t('dashboard.greeting');

  document.getElementById('dash-greeting-text').textContent = greeting + ',';
  document.getElementById('dash-alias').textContent = user.alias;
}

function renderStatusBars(user) {
  const weekly = getWeeklyLog();
  const maxHours = user.maxExtracurricularHours || 10;
  const energy = weekly.energyCurrent !== null ? weekly.energyCurrent : user.energyBaseline;

  // Energy
  document.getElementById('status-energy-val').textContent = `${energy}/10`;
  document.getElementById('status-energy-bar').style.width = `${(energy / 10) * 100}%`;

  // Hours
  const hoursUsed = weekly.hoursUsed || 0;
  document.getElementById('status-hours-val').textContent = `${hoursUsed}/${maxHours}h ${t('dashboard.hoursUnit')}`;
  const hoursPct = Math.min((hoursUsed / maxHours) * 100, 100);
  document.getElementById('status-hours-bar').style.width = `${hoursPct}%`;
  
  // Color warning if over budget
  const hoursBar = document.getElementById('status-hours-bar');
  if (hoursUsed > maxHours) {
    hoursBar.style.background = `linear-gradient(90deg, var(--danger), var(--warning))`;
  }

  // Committed count
  const committed = getCommittedActivities();
  document.getElementById('status-committed-val').textContent = committed.length;
}

function renderWeekCalendar() {
  const container = document.getElementById('week-calendar');
  const weekStart = getWeekStart();
  const activities = getCommittedActivities();
  const academicTasks = loadAcademicTasks();
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const dayNames = [
    t('dashboard.mon'), t('dashboard.tue'), t('dashboard.wed'),
    t('dashboard.thu'), t('dashboard.fri'), t('dashboard.sat'), t('dashboard.sun')
  ];

  let html = '';
  for (let i = 0; i < 7; i++) {
    const date = new Date(weekStart);
    date.setDate(date.getDate() + i);
    const dateStr = date.toISOString().split('T')[0];
    const isToday = date.getTime() === today.getTime();

    // Count activities on this day
    const dayActivities = activities.filter(a => a.date === dateStr);
    const dayAcademic = academicTasks.filter(a => a.date === dateStr);

    let dots = '';
    dayActivities.forEach(() => { dots += '<span class="cal-dot"></span>'; });
    dayAcademic.forEach(a => {
      const cls = a.type === 'exam' ? 'cal-dot--exam' : 'cal-dot--academic';
      dots += `<span class="cal-dot ${cls}"></span>`;
    });

    html += `
      <div class="cal-day ${isToday ? 'today' : ''}">
        <span class="cal-day-name">${dayNames[i]}</span>
        <span class="cal-day-num">${date.getDate()}</span>
        <div class="cal-dots">${dots}</div>
      </div>
    `;
  }
  container.innerHTML = html;
}

function renderCommittedActivities() {
  const container = document.getElementById('committed-list');
  const activities = getCommittedActivities();

  if (activities.length === 0) {
    container.innerHTML = `<p class="no-items">${t('dashboard.noActivities')}</p>`;
    return;
  }

  // Sort by date descending
  const sorted = [...activities].sort((a, b) => new Date(b.date) - new Date(a.date));

  container.innerHTML = sorted.map(act => {
    const statusClass = act.status === 'committed' ? 'status-committed' : 'status-dropped';
    const statusText = act.status === 'committed' ? t('dashboard.status_committed') : t('dashboard.status_dropped');
    const timeStr = act.time ? formatTime(act.time) : '';
    const meta = [
      act.location ? `📍 ${act.location}` : '',
      act.date ? formatDate(act.date) : '',
      timeStr ? `🕐 ${timeStr}` : '',
      act.duration ? `${act.duration}h` : '',
    ].filter(Boolean).join(' · ');

    return `
      <div class="activity-card">
        <div class="activity-card-header">
          <div class="activity-card-name">${act.name}</div>
          <div class="activity-card-actions">
            <button class="activity-card-remove" data-id="${act.id}" title="Remove">×</button>
          </div>
        </div>
        <div class="activity-card-meta">${meta}</div>
        <span class="activity-card-status ${statusClass}">${statusText}</span>
      </div>
    `;
  }).join('');

  // Bind remove events
  container.querySelectorAll('.activity-card-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      showConfirmDialog(t('dashboard.removeConfirm'), () => {
        removeActivity(id);
        recalcWeeklyLog();
        renderStatusBars(loadUser());
        renderCommittedActivities();
        renderWeekCalendar();
      });
    });
  });
}

function renderAcademicChecklist() {
  const container = document.getElementById('academic-list');
  const tasks = loadAcademicTasks();

  if (tasks.length === 0) {
    container.innerHTML = `<p class="no-items">${t('dashboard.noTasks')}</p>`;
    return;
  }

  // Sort: incomplete first, then by date
  const sorted = [...tasks].sort((a, b) => {
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    return new Date(a.date) - new Date(b.date);
  });

  container.innerHTML = sorted.map(task => {
    const typeClass = `badge-${task.type}`;
    const typeLabels = {
      exam: t('dashboard.examLabel'),
      assignment: t('dashboard.assignmentLabel'),
      project: t('dashboard.projectLabel'),
      presentation: t('dashboard.presentationLabel'),
    };

    return `
      <div class="academic-item ${task.completed ? 'completed' : ''}" data-id="${task.id}">
        <input type="checkbox" class="academic-checkbox" ${task.completed ? 'checked' : ''} data-task-id="${task.id}">
        <div class="academic-item-content">
          <div class="academic-item-title">${task.subject}${task.description ? ' — ' + task.description : ''}</div>
          <div class="academic-item-meta">
            <span class="academic-type-badge ${typeClass}">${typeLabels[task.type] || task.type}</span>
            <span>${t('dashboard.dueLabel')}: ${formatDate(task.date)}</span>
            ${task.estHours ? `<span>${task.estHours} ${t('dashboard.estHours')}</span>` : ''}
          </div>
        </div>
        <button class="academic-item-delete" data-task-id="${task.id}" title="Delete">×</button>
      </div>
    `;
  }).join('');

  // Bind checkbox events
  container.querySelectorAll('.academic-checkbox').forEach(chk => {
    chk.addEventListener('change', () => {
      toggleAcademicTask(chk.dataset.taskId);
      renderAcademicChecklist();
    });
  });

  // Bind delete events
  container.querySelectorAll('.academic-item-delete').forEach(btn => {
    btn.addEventListener('click', () => {
      deleteAcademicTask(btn.dataset.taskId);
      renderAcademicChecklist();
      renderWeekCalendar();
    });
  });
}

function renderMotivationBoard() {
  const container = document.getElementById('motivation-list');
  const achs = loadAchievements();

  if (achs.length === 0) {
    container.innerHTML = `<p class="no-items">${t('motivation.noItems')}</p>`;
    return;
  }

  // Sort descending
  const sorted = [...achs].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  container.innerHTML = sorted.map(ach => `
    <div class="activity-card" style="border-left: 4px solid var(--accent);">
      <div class="activity-card-header">
        <div class="activity-card-name" style="font-weight: 500;">🏆 ${ach.text}</div>
        <div class="activity-card-actions">
          <button class="activity-card-remove mot-remove" data-id="${ach.id}" title="Remove">×</button>
        </div>
      </div>
      <div class="activity-card-meta">${formatDate(ach.createdAt)}</div>
    </div>
  `).join('');

  container.querySelectorAll('.mot-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      showConfirmDialog(t('dashboard.removeConfirm'), () => {
        removeAchievement(btn.dataset.id);
        renderMotivationBoard();
      });
    });
  });
}

let dashBound = false;
function bindDashboardActions() {
  if (dashBound) return;
  dashBound = true;

  document.getElementById('btn-add-activity').addEventListener('click', () => navigateTo('add-activity'));
  document.getElementById('btn-ai-friend').addEventListener('click', () => navigateTo('ai-friend'));
  document.getElementById('btn-find-mentor').addEventListener('click', () => navigateTo('mentor'));
  document.getElementById('btn-gpa').addEventListener('click', () => navigateTo('gpa'));
  document.getElementById('btn-check-activity').addEventListener('click', () => {
    // Scroll to committed activities
    document.getElementById('committed-title').scrollIntoView({ behavior: 'smooth' });
  });
  document.getElementById('btn-settings').addEventListener('click', () => navigateTo('onboarding'));

  // Academic task modals
  document.getElementById('btn-add-exam').addEventListener('click', () => openAcademicModal('exam'));
  document.getElementById('btn-add-task').addEventListener('click', () => openAcademicModal('task'));

  // Motivation modal
  document.getElementById('btn-add-motivation').addEventListener('click', () => {
    document.getElementById('motivation-form').reset();
    document.getElementById('modal-motivation').classList.remove('hidden');
  });
}

function openAcademicModal(type) {
  const modal = document.getElementById('modal-academic');
  const title = document.getElementById('modal-academic-title');
  const typeSelect = document.getElementById('acad-type');

  if (type === 'exam') {
    title.textContent = t('academic.addExamTitle');
    typeSelect.value = 'exam';
  } else {
    title.textContent = t('academic.addTaskTitle');
    typeSelect.value = 'assignment';
  }

  // Reset form
  document.getElementById('academic-form').reset();
  typeSelect.value = type === 'exam' ? 'exam' : 'assignment';
  document.getElementById('acad-date').value = new Date().toISOString().split('T')[0];

  modal.classList.remove('hidden');
}

function bindAcademicModal() {
  const modal = document.getElementById('modal-academic');
  const form = document.getElementById('academic-form');
  const cancelBtn = document.getElementById('btn-acad-cancel');
  const overlay = modal.querySelector('.modal-overlay');
  const parseBtn = document.getElementById('btn-parse-schedule');

  // Close modal
  function closeModal() { modal.classList.add('hidden'); }
  cancelBtn.addEventListener('click', closeModal);
  overlay.addEventListener('click', closeModal);

  // Save
  form.onsubmit = (e) => {
    e.preventDefault();
    const task = {
      subject: document.getElementById('acad-subject').value.trim(),
      date: document.getElementById('acad-date').value,
      type: document.getElementById('acad-type').value,
      description: document.getElementById('acad-desc').value.trim(),
      estHours: parseFloat(document.getElementById('acad-hours').value) || 2,
    };

    if (!task.subject || !task.date) {
      showToast(getLang() === 'vi' ? 'Điền đầy đủ thông tin' : 'Fill in all required fields');
      return;
    }

    addAcademicTask(task);
    closeModal();
    renderAcademicChecklist();
    renderWeekCalendar();
    showToast(getLang() === 'vi' ? 'Đã thêm!' : 'Added!');
  });

  // Parse schedule text
  parseBtn.addEventListener('click', () => {
    const text = document.getElementById('acad-paste').value.trim();
    if (!text) return;

    // Simple date extraction: look for patterns like "15/06", "June 15", "2026-06-15"
    const datePatterns = [
      /(\d{1,2})[\/\-](\d{1,2})[\/\-]?(\d{2,4})?/g,
      /(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*/gi,
    ];

    let found = 0;
    const lines = text.split('\n');
    lines.forEach(line => {
      if (!line.trim()) return;
      
      // Try to find a date in the line
      const match = line.match(/(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/) ||
                    line.match(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/) ||
                    line.match(/(\d{1,2})[\/\-](\d{1,2})/);
      
      if (match) {
        let dateStr;
        if (match[0].match(/^\d{4}/)) {
          dateStr = match[0];
        } else {
          const parts = match[0].split(/[\/\-]/);
          const day = parts[0].padStart(2, '0');
          const month = parts[1].padStart(2, '0');
          const year = parts[2] ? (parts[2].length === 2 ? '20' + parts[2] : parts[2]) : new Date().getFullYear();
          dateStr = `${year}-${month}-${day}`;
        }

        // Remove the date from the line to get the subject
        const subject = line.replace(match[0], '').replace(/[-–—:,]/g, ' ').trim();
        
        if (subject) {
          addAcademicTask({
            subject: subject.substring(0, 50),
            date: dateStr,
            type: line.toLowerCase().includes('thi') || line.toLowerCase().includes('exam') ? 'exam' : 'assignment',
            description: '',
            estHours: 2,
          });
          found++;
        }
      }
    });

    if (found > 0) {
      document.getElementById('acad-paste').value = '';
      document.getElementById('modal-academic').classList.add('hidden');
      renderAcademicChecklist();
      renderWeekCalendar();
      showToast(getLang() === 'vi' ? `Đã thêm ${found} mục` : `Added ${found} items`);
    } else {
      showToast(getLang() === 'vi' ? 'Không tìm thấy ngày hợp lệ' : 'No valid dates found');
    }
  });
}

function initMotivationModal() {
  const modal = document.getElementById('modal-motivation');
  const form = document.getElementById('motivation-form');
  const cancelBtn = document.getElementById('btn-mot-cancel');
  const overlay = modal.querySelector('.modal-overlay');

  const closeModal = () => modal.classList.add('hidden');
  cancelBtn.addEventListener('click', closeModal);
  overlay.addEventListener('click', closeModal);

  form.onsubmit = (e) => {
    e.preventDefault();
    const text = document.getElementById('mot-text').value.trim();
    if (text) {
      addAchievement(text);
      closeModal();
      renderMotivationBoard();
      showToast(getLang() === 'vi' ? 'Đã lưu thành tựu!' : 'Achievement saved!');
    }
  });
}

function renderDashboardText() {
  document.getElementById('action-check').textContent = t('dashboard.checkActivity');
  document.getElementById('action-ai').textContent = t('dashboard.aiFriend');
  document.getElementById('action-mentor').textContent = t('dashboard.findMentor');
  document.getElementById('action-add').textContent = t('dashboard.addActivity');
  document.getElementById('status-energy-label').textContent = t('dashboard.energyLabel');
  document.getElementById('status-hours-label').textContent = t('dashboard.hoursLabel');
  document.getElementById('status-committed-label').textContent = t('dashboard.committedLabel');
  document.getElementById('calendar-title').textContent = t('dashboard.calendarTitle');
  document.getElementById('committed-title').textContent = t('dashboard.committedTitle');
  document.getElementById('academic-title').textContent = t('dashboard.academicTitle');
  document.getElementById('lbl-add-exam').textContent = t('dashboard.addExam');
  document.getElementById('lbl-add-task').textContent = t('dashboard.addTask');

  // Academic modal
  document.getElementById('acad-lbl-subject').textContent = t('academic.subjectLabel');
  document.getElementById('acad-subject').placeholder = t('academic.subjectPlaceholder');
  document.getElementById('acad-lbl-date').textContent = t('academic.dateLabel');
  document.getElementById('acad-lbl-type').textContent = t('academic.typeLabel');
  document.getElementById('acad-opt-exam').textContent = t('academic.typeExam');
  document.getElementById('acad-opt-assignment').textContent = t('academic.typeAssignment');
  document.getElementById('acad-opt-project').textContent = t('academic.typeProject');
  document.getElementById('acad-opt-presentation').textContent = t('academic.typePresentation');
  document.getElementById('acad-lbl-desc').textContent = t('academic.descLabel');
  document.getElementById('acad-desc').placeholder = t('academic.descPlaceholder');
  document.getElementById('acad-lbl-hours').textContent = t('academic.estHoursLabel');
  document.getElementById('btn-acad-cancel').textContent = t('academic.cancel');
  document.getElementById('btn-acad-save').textContent = t('academic.save');
  document.getElementById('acad-lbl-paste').textContent = t('academic.pasteLabel');
  document.getElementById('acad-paste').placeholder = t('academic.pastePlaceholder');
  document.getElementById('btn-parse-schedule').textContent = t('academic.parseBtn');

  // Motivation
  document.getElementById('motivation-title').textContent = t('motivation.title');
  document.getElementById('motivation-subtitle').textContent = t('motivation.subtitle');
  document.getElementById('lbl-add-motivation').textContent = t('motivation.addBtn');
  document.getElementById('modal-motivation-title').textContent = t('motivation.modalTitle');
  document.getElementById('modal-motivation-subtitle').textContent = t('motivation.subtitle');
  document.getElementById('mot-text').placeholder = t('motivation.placeholder');
  document.getElementById('btn-mot-cancel').textContent = t('motivation.cancel');
  document.getElementById('btn-mot-save').textContent = t('motivation.save');
}

// Utility
function formatDate(dateStr) {
  const d = new Date(dateStr);
  const lang = getLang();
  if (lang === 'vi') {
    return `${d.getDate()}/${d.getMonth() + 1}`;
  }
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${months[d.getMonth()]} ${d.getDate()}`;
}

function formatTime(timeStr) {
  if (!timeStr) return '';
  const parts = timeStr.split(':');
  if (parts.length < 2) return timeStr;
  const h = parseInt(parts[0]);
  const m = parseInt(parts[1]);
  if (isNaN(h) || isNaN(m)) return timeStr;
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  const minStr = m === 0 ? '00' : '30';
  const lang = getLang();
  let period = '';
  if (lang === 'vi') {
    period = h < 12 ? 'SA' : 'CH';
  } else {
    period = h < 12 ? 'a.m.' : 'p.m.';
  }
  return `${hour12}:${minStr} ${period}`;
}
