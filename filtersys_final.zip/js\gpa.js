// ═══════════════════════════════════════════════
// FilterSys — GPA & Honors Calculator
// ═══════════════════════════════════════════════

function calculateCourseFinal(ccWeight, ccGrade, gkWeight, gkGrade, ckWeight, ckGrade) {
  return (ccWeight * ccGrade + gkWeight * gkGrade + ckWeight * ckGrade) / 100;
}

function convertToGPA(final10) {
  if (final10 >= 8.5) return { gpa: 4.0, letter: 'A' };
  if (final10 >= 7.0) return { gpa: 3.0, letter: 'B' };
  if (final10 >= 5.5) return { gpa: 2.0, letter: 'C' };
  if (final10 >= 4.0) return { gpa: 1.0, letter: 'D' };
  return { gpa: 0.0, letter: 'F' };
}

function calculateSemesterGPA(courses) {
  let totalCredits = 0;
  let totalPoints = 0;
  
  courses.forEach(c => {
    if (c.credits > 0) {
      totalCredits += c.credits;
      const final10 = calculateCourseFinal(c.ccW, c.ccG, c.gkW, c.gkG, c.ckW, c.ckG);
      const { gpa } = convertToGPA(final10);
      totalPoints += gpa * c.credits;
    }
  });

  return totalCredits === 0 ? 0 : totalPoints / totalCredits;
}

function getHonorsClass(cpa, totalCredits, retakeCredits) {
  let tier = 0; // 5: Xuat sac, 4: Gioi, 3: Kha, 2: TB Kha, 1: TB, 0: Yeu
  
  if (cpa >= 3.6) tier = 5;
  else if (cpa >= 3.2) tier = 4;
  else if (cpa >= 2.5) tier = 3;
  else if (cpa >= 2.2) tier = 2;
  else if (cpa >= 2.0) tier = 1;
  else tier = 0;

  let downgrade = false;
  if (totalCredits > 0 && (retakeCredits / totalCredits) > 0.05) {
    if (tier > 0) {
      tier -= 1;
      downgrade = true;
    }
  }

  const tiersEn = ['Poor', 'Average', 'Above Average', 'Good', 'Very Good', 'Excellent'];
  const tiersVi = ['Yếu', 'Trung bình', 'Trung bình khá', 'Khá', 'Giỏi', 'Xuất sắc'];
  
  const lang = getLang();
  const name = lang === 'vi' ? tiersVi[tier] : tiersEn[tier];
  
  return { tier, name, downgrade };
}

// ─── UI Controllers ───

function initGPA() {
  renderGPACourses();
  calculateAllGPA();
  bindGPAActions();
}

function renderGPACourses() {
  const container = document.getElementById('gpa-courses-list');
  const courses = loadCourses();
  
  if (courses.length === 0) {
    container.innerHTML = `<p class="no-items text-muted">${t('gpa.noCourses')}</p>`;
    return;
  }

  container.innerHTML = courses.map((c, i) => {
    const final10 = calculateCourseFinal(c.ccW, c.ccG, c.gkW, c.gkG, c.ckW, c.ckG);
    const { gpa, letter } = convertToGPA(final10);
    const badgeCls = gpa >= 3.0 ? 'badge-exam' : gpa >= 2.0 ? 'badge-project' : 'badge-assignment';
    
    return `
      <div class="activity-card" data-index="${i}">
        <div class="activity-card-header">
          <div class="activity-card-name">${c.name || t('gpa.unnamed')} (${c.credits} cr)</div>
          <div class="activity-card-actions">
            <button class="activity-card-remove gpa-remove" data-index="${i}" title="Remove">×</button>
          </div>
        </div>
        <div class="activity-card-meta">
          <span>CC: ${c.ccG} (${c.ccW}%)</span> · 
          <span>GK: ${c.gkG} (${c.gkW}%)</span> · 
          <span>CK: ${c.ckG} (${c.ckW}%)</span>
        </div>
        <div style="margin-top: 0.5rem; display: flex; gap: 0.5rem; align-items: center;">
          <span class="academic-type-badge ${badgeCls}">${final10.toFixed(1)}/10</span>
          <span class="academic-type-badge" style="background: var(--surface-light); border: 1px solid var(--border);">${letter} (${gpa.toFixed(1)})</span>
        </div>
      </div>
    `;
  }).join('');

  container.querySelectorAll('.gpa-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.dataset.index);
      const courses = loadCourses();
      courses.splice(idx, 1);
      saveCourses(courses);
      renderGPACourses();
      calculateAllGPA();
    });
  });
}

function calculateAllGPA() {
  const courses = loadCourses();
  const semGPA = calculateSemesterGPA(courses);
  const semCredits = courses.reduce((sum, c) => sum + c.credits, 0);
  
  const user = loadUser();
  const cpaData = loadCPAData();
  
  let cumPoints = cpaData.cumulativePoints || 0;
  let cumCredits = cpaData.cumulativeCredits || 0;
  
  // Predict total CPA if this semester completes
  const predictedCPA = (cumPoints + (semGPA * semCredits)) / (cumCredits + semCredits) || 0;
  
  document.getElementById('gpa-semester-val').textContent = semGPA.toFixed(2);
  document.getElementById('gpa-cpa-val').textContent = predictedCPA.toFixed(2);
  
  const totalRetake = (cpaData.retakeCredits || 0) + parseInt(document.getElementById('gpa-sem-retake').value || 0);
  const totalCreds = cumCredits + semCredits;
  
  const honors = getHonorsClass(predictedCPA, totalCreds, totalRetake);
  
  document.getElementById('gpa-honors-val').textContent = honors.name;
  if (honors.downgrade) {
    document.getElementById('gpa-honors-val').innerHTML += ` <span title="Downgraded due to >5% retake credits" style="color: var(--danger);">⚠️</span>`;
  }
}

let gpaBound = false;

function bindGPAActions() {
  if (gpaBound) return;
  gpaBound = true;

  document.getElementById('btn-add-course').addEventListener('click', () => {
    document.getElementById('course-form').reset();
    document.getElementById('modal-course').classList.remove('hidden');
  });

  const modal = document.getElementById('modal-course');
  const cancelBtn = document.getElementById('btn-course-cancel');
  const overlay = modal.querySelector('.modal-overlay');

  const closeModal = () => modal.classList.add('hidden');
  cancelBtn.addEventListener('click', closeModal);
  overlay.addEventListener('click', closeModal);

  document.getElementById('course-form').onsubmit = (e) => {
    e.preventDefault();
    const course = {
      name: document.getElementById('course-name').value.trim(),
      credits: parseInt(document.getElementById('course-credits').value) || 3,
      ccW: parseInt(document.getElementById('course-cc-w').value) || 10,
      ccG: parseFloat(document.getElementById('course-cc-g').value) || 0,
      gkW: parseInt(document.getElementById('course-gk-w').value) || 30,
      gkG: parseFloat(document.getElementById('course-gk-g').value) || 0,
      ckW: parseInt(document.getElementById('course-ck-w').value) || 60,
      ckG: parseFloat(document.getElementById('course-ck-g').value) || 0,
    };
    
    if (course.ccW + course.gkW + course.ckW !== 100) {
      showToast(getLang() === 'vi' ? 'Tổng trọng số phải bằng 100%' : 'Total weights must equal 100%');
      return;
    }
    
    const courses = loadCourses();
    courses.push(course);
    saveCourses(courses);
    
    closeModal();
    renderGPACourses();
    calculateAllGPA();
  });
  
  document.getElementById('gpa-sem-retake').addEventListener('input', calculateAllGPA);

  document.getElementById('btn-end-semester').addEventListener('click', () => {
    showConfirmDialog(t('gpa.confirmEndSem'), () => {
      const courses = loadCourses();
      const semGPA = calculateSemesterGPA(courses);
      const semCredits = courses.reduce((sum, c) => sum + c.credits, 0);
      const semRetake = parseInt(document.getElementById('gpa-sem-retake').value) || 0;
      
      const cpaData = loadCPAData();
      cpaData.cumulativePoints += (semGPA * semCredits);
      cpaData.cumulativeCredits += semCredits;
      cpaData.retakeCredits += semRetake;
      
      saveCPAData(cpaData);
      
      // Clear semester
      saveCourses([]);
      saveActivities([]);
      saveAcademicTasks([]);
      
      // Increment semester in user profile
      const user = loadUser();
      user.semester += 1;
      user.currentGPA = cpaData.cumulativePoints / cpaData.cumulativeCredits;
      saveUser(user);
      
      showToast(t('gpa.semEndedMsg'));
      renderGPACourses();
      calculateAllGPA();
      navigateTo('dashboard');
    });
  });
}

function renderGPAText() {
  document.getElementById('gpa-title').textContent = t('gpa.title');
  document.getElementById('gpa-semester-lbl').textContent = t('gpa.semesterLbl');
  document.getElementById('gpa-cpa-lbl').textContent = t('gpa.cpaLbl');
  document.getElementById('gpa-honors-lbl').textContent = t('gpa.honorsLbl');
  document.getElementById('gpa-sem-retake-lbl').textContent = t('gpa.retakeLbl');
  document.getElementById('gpa-courses-title').textContent = t('gpa.coursesTitle');
  document.getElementById('lbl-add-course').textContent = t('gpa.addCourse');
  document.getElementById('btn-end-semester').textContent = t('gpa.endSem');
  document.getElementById('modal-course-title').textContent = t('gpa.modalTitle');
  document.getElementById('course-lbl-name').textContent = t('gpa.courseName');
  document.getElementById('course-lbl-credits').textContent = t('gpa.credits');
  document.getElementById('course-lbl-ccw').textContent = t('gpa.ccWeight');
  document.getElementById('course-lbl-gkw').textContent = t('gpa.gkWeight');
  document.getElementById('course-lbl-ckw').textContent = t('gpa.ckWeight');
  document.getElementById('course-lbl-ccg').textContent = t('gpa.ccGrade');
  document.getElementById('course-lbl-gkg').textContent = t('gpa.gkGrade');
  document.getElementById('course-lbl-ckg').textContent = t('gpa.ckGrade');
  document.getElementById('btn-course-cancel').textContent = t('common.back');
  document.getElementById('btn-course-save').textContent = t('academic.save');
}
