// ═══════════════════════════════════════════════
// FilterSys — Mentor Page (Interactive Flow)
// ═══════════════════════════════════════════════

let selectedMentor = null;

function initMentor() {
  selectedMentor = null;
  document.getElementById('mentor-select').classList.remove('hidden');
  document.getElementById('mentor-conversation').classList.add('hidden');
  document.getElementById('mentor-chat').innerHTML = '';

  // Bind mentor cards
  document.querySelectorAll('.mentor-card').forEach(card => {
    card.onclick = () => selectMentor(card.dataset.mentor);
  });

  // Back button
  document.getElementById('btn-mentor-back').onclick = () => {
    selectedMentor = null;
    document.getElementById('mentor-select').classList.remove('hidden');
    document.getElementById('mentor-conversation').classList.add('hidden');
  };

  // Ask button
  document.getElementById('btn-mentor-ask').onclick = () => askMentor();
  document.getElementById('mentor-input').onkeydown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      askMentor();
    }
  };
}

function selectMentor(type) {
  selectedMentor = type;
  document.getElementById('mentor-select').classList.add('hidden');
  document.getElementById('mentor-conversation').classList.remove('hidden');

  const chat = document.getElementById('mentor-chat');
  const lang = getLang();
  const user = loadUser();

  document.getElementById('mentor-disclaimer').textContent = t('mentor.disclaimer');

  // Mentor introduction
  const intros = getMentorIntros(type, lang, user);
  chat.innerHTML = `<div class="chat-bubble chat-bubble--ai">${intros}</div>`;

  document.getElementById('mentor-input').placeholder = t('mentor.promptPlaceholder');
  document.getElementById('mentor-input').focus();
}

function askMentor() {
  const input = document.getElementById('mentor-input');
  const text = input.value.trim();
  if (!text || !selectedMentor) return;

  const chat = document.getElementById('mentor-chat');
  const user = loadUser();
  const lang = getLang();

  // Add user message
  chat.innerHTML += `<div class="chat-bubble chat-bubble--user">${escapeHtml(text)}</div>`;
  input.value = '';

  // Generate mentor response
  setTimeout(() => {
    const response = generateMentorResponse(selectedMentor, text, user, lang);
    chat.innerHTML += `<div class="chat-bubble chat-bubble--ai">${response}</div>`;
    chat.scrollTop = chat.scrollHeight;
  }, 500);

  chat.scrollTop = chat.scrollHeight;
}

function getMentorIntros(type, lang, user) {
  const alias = user ? user.alias : '';
  
  const intros = {
    academic: {
      en: `Hello${alias ? ', ' + alias : ''}. I'm The Academic. I prioritize GPA above everything else — because in the end, your transcript follows you longer than any club memory.<br><br>Tell me what's bothering you. Be specific: what event or situation is creating FOMO for you right now?`,
      vi: `Xin chào${alias ? ', ' + alias : ''}. Tôi là Người Học Thuật. Tôi ưu tiên GPA trên tất cả — vì bảng điểm theo bạn lâu hơn bất kỳ kỷ niệm câu lạc bộ nào.<br><br>Hãy cho tôi biết điều gì đang khiến bạn băn khoăn. Cụ thể: sự kiện hay tình huống nào đang tạo FOMO cho bạn?`
    },
    career: {
      en: `Hey${alias ? ', ' + alias : ''}. I'm The Career Builder. Every hour is an investment — the question is whether the ROI is worth it.<br><br>What opportunity are you considering? Let's evaluate its real career value.`,
      vi: `Chào${alias ? ', ' + alias : ''}. Tôi là Người Xây Dựng Sự Nghiệp. Mỗi giờ là một khoản đầu tư — vấn đề là lợi ích có xứng đáng không.<br><br>Bạn đang xem xét cơ hội nào? Hãy đánh giá giá trị thực tế cho sự nghiệp.`
    },
    realist: {
      en: `Hi${alias ? ', ' + alias : ''}. I'm The Realist. I don't optimize for perfection — I optimize for sustainability. Burning out helps nobody.<br><br>What's the situation? Tell me what you're feeling pulled toward, and I'll help you see if it's worth the energy.`,
      vi: `Xin chào${alias ? ', ' + alias : ''}. Tôi là Người Thực Tế. Tôi không tối ưu cho sự hoàn hảo — tôi tối ưu cho sự bền vững. Kiệt sức không giúp ích gì cho ai.<br><br>Tình huống thế nào? Hãy cho tôi biết điều gì đang kéo bạn, và tôi sẽ giúp bạn xem nó có đáng để dành năng lượng không.`
    }
  };

  return intros[type][lang] || intros[type].en;
}

function generateMentorResponse(mentorType, userText, user, lang) {
  const textLower = userText.toLowerCase();
  const weekly = getWeeklyLog();
  const committed = getCommittedActivities();
  const maxHours = user ? user.maxExtracurricularHours : 10;
  const hoursUsed = weekly.hoursUsed || 0;
  const energy = weekly.energyCurrent !== null ? weekly.energyCurrent : (user ? user.energyBaseline : 7);
  const exams = getExamsWithinDays(7);
  const incomplete = getIncompleteTasksThisWeek();

  // Context data string
  const contextData = lang === 'vi'
    ? `[Dữ liệu: ${hoursUsed}/${maxHours}h ngoại khóa tuần này, năng lượng ${energy}/10, ${committed.length} hoạt động đã cam kết, ${exams.length} kỳ thi sắp tới, ${incomplete.length} bài tập chưa xong]`
    : `[Data: ${hoursUsed}/${maxHours}h extracurriculars this week, energy ${energy}/10, ${committed.length} committed activities, ${exams.length} upcoming exams, ${incomplete.length} incomplete tasks]`;

  // Detect themes
  const isFOMO = /fomo|bỏ lỡ|missing|left out|mọi người|everyone|ai cũng/i.test(textLower);
  const isOvercommit = /too many|quá nhiều|overwhelm|nhiều quá|commit|cam kết/i.test(textLower);
  const isQuit = /quit|rời|leave|bỏ|drop|nghỉ/i.test(textLower);
  const isGuilty = /guilt|tội lỗi|có lỗi|sorry|feel bad|áy náy/i.test(textLower);
  const isConfused = /don't know|không biết|confused|phân vân|uncertain|lưỡng lự/i.test(textLower);

  // Mentor-specific responses
  const responses = {
    academic: {
      fomo: {
        en: `${contextData}<br><br>Let's be direct: FOMO doesn't add points to your GPA. Every event you attend "because everyone else is going" is time subtracted from your academic performance.<br><br>You have ${hoursUsed}h committed this week out of ${maxHours}h budget.${exams.length > 0 ? ` And you have ${exams.length} exam(s) coming up.` : ''} Every hour matters.<br><br><strong>My advice:</strong> Before saying yes, ask yourself: "Will this help my grades?" If the answer is no, it's a no. Your peers will forget this event in a week. Your transcript is permanent.`,
        vi: `${contextData}<br><br>Nói thẳng: FOMO không cộng điểm vào GPA. Mỗi sự kiện bạn tham gia "vì mọi người đều đi" là thời gian trừ đi từ kết quả học tập.<br><br>Bạn đã cam kết ${hoursUsed}h tuần này trong ngân sách ${maxHours}h.${exams.length > 0 ? ` Và bạn có ${exams.length} kỳ thi sắp tới.` : ''} Mỗi giờ đều quan trọng.<br><br><strong>Lời khuyên:</strong> Trước khi đồng ý, hãy tự hỏi: "Điều này có giúp điểm số không?" Nếu câu trả lời là không, thì đó là không. Bạn bè sẽ quên sự kiện này trong một tuần. Bảng điểm thì vĩnh viễn.`
      },
      overcommit: {
        en: `${contextData}<br><br>You're at ${hoursUsed}h out of ${maxHours}h. ${hoursUsed > maxHours ? "That's already over your budget." : "Getting close to the limit."}<br><br>${incomplete.length > 0 ? `You also have ${incomplete.length} unfinished academic tasks. ` : ''}Every additional commitment directly competes with study time.<br><br><strong>Recommendation:</strong> Rank all your current commitments by academic relevance. Drop the bottom one. No negotiation.`,
        vi: `${contextData}<br><br>Bạn đang ở mức ${hoursUsed}h trong tổng ${maxHours}h. ${hoursUsed > maxHours ? "Đã vượt ngân sách rồi." : "Sắp chạm giới hạn."}<br><br>${incomplete.length > 0 ? `Bạn còn ${incomplete.length} bài tập chưa hoàn thành. ` : ''}Mỗi cam kết thêm trực tiếp cạnh tranh với thời gian học.<br><br><strong>Đề xuất:</strong> Xếp hạng tất cả cam kết hiện tại theo mức độ liên quan đến học tập. Bỏ cái cuối cùng. Không thương lượng.`
      },
      default: {
        en: `${contextData}<br><br>Here's what the numbers say: You've used ${hoursUsed} of ${maxHours} hours this week. Your energy is at ${energy}/10. ${exams.length > 0 ? `You have ${exams.length} exam(s) ahead.` : ''}<br><br>From a pure academic standpoint, any activity that doesn't directly contribute to your coursework is optional. And "optional" means you need a very good reason.<br><br>What specifically are you trying to decide?`,
        vi: `${contextData}<br><br>Dữ liệu cho thấy: Bạn đã dùng ${hoursUsed} trong ${maxHours} giờ tuần này. Năng lượng ở mức ${energy}/10. ${exams.length > 0 ? `Bạn có ${exams.length} kỳ thi phía trước.` : ''}<br><br>Từ góc nhìn thuần học thuật, bất kỳ hoạt động nào không trực tiếp đóng góp vào môn học đều là tùy chọn. Và "tùy chọn" nghĩa là bạn cần lý do rất chính đáng.<br><br>Cụ thể bạn đang cần quyết định điều gì?`
      }
    },
    career: {
      fomo: {
        en: `${contextData}<br><br>FOMO is a terrible career advisor. The best professionals I know got there by being strategic, not by attending every event.<br><br>Ask yourself: "Can I name 3 specific people at this event who could advance my career?" If not, it's socializing — not networking. There's a difference.<br><br><strong>Career calculation:</strong> One meaningful connection > 10 events attended out of obligation. Invest your ${maxHours - hoursUsed}h remaining wisely.`,
        vi: `${contextData}<br><br>FOMO là một cố vấn nghề nghiệp tồi. Những người thành công tôi biết đều đến đó bằng chiến lược, không phải bằng cách tham gia mọi sự kiện.<br><br>Hãy tự hỏi: "Bạn có thể kể tên 3 người cụ thể ở sự kiện này có thể giúp sự nghiệp không?" Nếu không, đó là giao lưu — không phải xây dựng mạng lưới. Có sự khác biệt.<br><br><strong>Tính toán nghề nghiệp:</strong> Một mối quan hệ có ý nghĩa > 10 sự kiện tham gia vì nghĩa vụ. Hãy đầu tư ${maxHours - hoursUsed}h còn lại một cách khôn ngoan.`
      },
      default: {
        en: `${contextData}<br><br>Let's think about ROI. You have ${maxHours - hoursUsed}h left in your weekly budget. Energy at ${energy}/10.<br><br>The career question isn't "Is this event good?" — it's "Is this the BEST use of my limited time for career growth?"<br><br>If you can get the same benefit from a 30-minute LinkedIn conversation instead of a 3-hour event, choose efficiency. What's the specific opportunity you're weighing?`,
        vi: `${contextData}<br><br>Hãy nghĩ về lợi ích đầu tư. Bạn còn ${maxHours - hoursUsed}h trong ngân sách tuần. Năng lượng ở ${energy}/10.<br><br>Câu hỏi nghề nghiệp không phải "Sự kiện này tốt không?" — mà là "Đây có phải cách SỬ DỤNG TỐT NHẤT thời gian hạn chế cho phát triển nghề nghiệp không?"<br><br>Nếu bạn có thể nhận cùng lợi ích từ cuộc trò chuyện 30 phút trên LinkedIn thay vì sự kiện 3 giờ, hãy chọn hiệu quả. Cơ hội cụ thể bạn đang cân nhắc là gì?`
      }
    },
    realist: {
      fomo: {
        en: `${contextData}<br><br>Here's the thing about FOMO: it's your brain telling you a story that isn't true. The story says "if you don't go, you'll miss something life-changing." Reality says most events are forgettable.<br><br>Your energy is ${energy}/10. Your hours are ${hoursUsed}/${maxHours}. ${energy <= 4 ? "You're running on fumes. " : ""}${incomplete.length > 0 ? `You have ${incomplete.length} things to finish first. ` : ""}<br><br><strong>The sustainable choice:</strong> Skip this one. Rest, finish your work, and show up fully present for the next thing that actually matters. One well-attended event beats three where you're mentally checked out.`,
        vi: `${contextData}<br><br>FOMO là câu chuyện não bạn tự kể — nhưng không đúng sự thật. Câu chuyện nói "nếu không đi, bạn sẽ bỏ lỡ điều gì đó thay đổi cuộc đời." Thực tế thì hầu hết sự kiện đều sẽ bị lãng quên.<br><br>Năng lượng: ${energy}/10. Giờ: ${hoursUsed}/${maxHours}. ${energy <= 4 ? "Bạn đang cạn kiệt. " : ""}${incomplete.length > 0 ? `Bạn còn ${incomplete.length} việc chưa xong. ` : ""}<br><br><strong>Lựa chọn bền vững:</strong> Bỏ qua lần này. Nghỉ ngơi, hoàn thành công việc, và xuất hiện toàn tâm ở sự kiện tiếp theo thực sự quan trọng. Một sự kiện tham gia trọn vẹn hơn ba sự kiện mà tâm trí bạn không có mặt.`
      },
      overcommit: {
        en: `${contextData}<br><br>Real talk: ${hoursUsed}h out of ${maxHours}h used, energy at ${energy}/10. ${hoursUsed >= maxHours ? "You're already over capacity." : "You're getting close to burnout territory."}<br><br>Overcommitting isn't dedication — it's self-sabotage in disguise. You end up doing 5 things at 60% instead of 3 things at 100%.<br><br><strong>Action plan:</strong> List everything you've committed to. For each item, honestly rate: "Would I sign up for this today, knowing what I know now?" Drop anything that scores below a 7/10.`,
        vi: `${contextData}<br><br>Nói thật: ${hoursUsed}h trong ${maxHours}h đã dùng, năng lượng ${energy}/10. ${hoursUsed >= maxHours ? "Bạn đã vượt quá sức." : "Bạn đang gần ngưỡng kiệt sức."}<br><br>Tham gia quá nhiều không phải là cống hiến — đó là tự phá hoại bản thân. Bạn sẽ làm 5 việc ở mức 60% thay vì 3 việc ở mức 100%.<br><br><strong>Kế hoạch:</strong> Liệt kê mọi thứ bạn đã cam kết. Với mỗi mục, tự hỏi thành thật: "Nếu biết những gì biết bây giờ, mình có đăng ký lại không?" Bỏ bất cứ thứ gì dưới 7/10.`
      },
      default: {
        en: `${contextData}<br><br>Let me give you the big picture: ${hoursUsed}h used, ${maxHours - hoursUsed}h remaining, energy ${energy}/10. ${committed.length} activities on your plate.<br><br>I don't do "should I or shouldn't I." I do "what can you sustain without burning out?" Because the semester is a marathon, not a sprint.<br><br>Tell me more about what you're wrestling with, and I'll help you find the balance point.`,
        vi: `${contextData}<br><br>Nhìn tổng thể: ${hoursUsed}h đã dùng, ${maxHours - hoursUsed}h còn lại, năng lượng ${energy}/10. ${committed.length} hoạt động trên vai.<br><br>Tôi không hỏi "có nên hay không." Tôi hỏi "bạn có thể duy trì mà không kiệt sức không?" Vì học kỳ là cuộc marathon, không phải chạy nước rút.<br><br>Hãy kể thêm về điều bạn đang băn khoăn, tôi sẽ giúp bạn tìm điểm cân bằng.`
      }
    }
  };

  const mentorResponses = responses[mentorType] || responses.realist;
  let response;

  if (isFOMO && mentorResponses.fomo) response = mentorResponses.fomo;
  else if (isOvercommit && mentorResponses.overcommit) response = mentorResponses.overcommit;
  else if (isQuit && mentorResponses.quit) response = mentorResponses.quit;
  else if (isGuilty && mentorResponses.guilty) response = mentorResponses.guilty;
  else response = mentorResponses.default;

  return response[lang] || response.en;
}

function renderMentorText() {
  document.getElementById('mentor-title').textContent = t('mentor.title');
  document.getElementById('mentor-subtitle').textContent = t('mentor.subtitle');
  document.getElementById('mentor-name-academic').textContent = t('mentor.academic');
  document.getElementById('mentor-desc-academic').textContent = t('mentor.academicDesc');
  document.getElementById('mentor-name-career').textContent = t('mentor.career');
  document.getElementById('mentor-desc-career').textContent = t('mentor.careerDesc');
  document.getElementById('mentor-name-realist').textContent = t('mentor.realist');
  document.getElementById('mentor-desc-realist').textContent = t('mentor.realistDesc');
  document.getElementById('btn-mentor-back').textContent = t('mentor.back');
  document.getElementById('btn-mentor-ask').textContent = t('mentor.askBtn');
  document.getElementById('mentor-input').placeholder = t('mentor.promptPlaceholder');
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
