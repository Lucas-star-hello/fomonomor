// ═══════════════════════════════════════════════
// FilterSys — Quiz & Onboarding Page
// ═══════════════════════════════════════════════

let currentQuizQ = 1;
let quizAnswers = [];
const TOTAL_QUIZ_Q = 3;

function initQuiz() {
  currentQuizQ = 1;
  quizAnswers = [];
  renderQuizQuestion();
}

function renderQuizQuestion() {
  if (currentQuizQ > TOTAL_QUIZ_Q) {
    finishQuiz();
    return;
  }

  const qKey = `q${currentQuizQ}`;
  document.getElementById('quiz-question-text').textContent = t(`quiz.${qKey}`);
  
  const optionsHtml = ['academics', 'career', 'income', 'growth', 'balance'].map(opt => `
    <label class="radio-card">
      <input type="radio" name="quiz-opt" value="${opt}">
      <span class="radio-icon">${getIconForGoal(opt)}</span>
      <span class="radio-text">${t(`quiz.${qKey}_${opt}`)}</span>
    </label>
  `).join('');
  
  document.getElementById('quiz-options').innerHTML = optionsHtml;
  
  const nextBtn = document.getElementById('btn-quiz-next');
  nextBtn.disabled = true;
  nextBtn.textContent = (currentQuizQ === TOTAL_QUIZ_Q) ? t('quiz.finishBtn') : t('quiz.nextBtn');
  
  // Re-attach event listener by cloning to clear previous click listeners
  const newNextBtn = nextBtn.cloneNode(true);
  nextBtn.parentNode.replaceChild(newNextBtn, nextBtn);
  
  // Listen for selection on the active DOM button
  document.querySelectorAll('input[name="quiz-opt"]').forEach(radio => {
    radio.addEventListener('change', () => {
      newNextBtn.disabled = false;
    });
  });
  
  newNextBtn.addEventListener('click', () => {
    const selected = document.querySelector('input[name="quiz-opt"]:checked');
    if (selected) {
      quizAnswers.push(selected.value);
      currentQuizQ++;
      renderQuizQuestion();
    }
  });
}

function finishQuiz() {
  // Determine most frequent answer
  const counts = {};
  quizAnswers.forEach(a => counts[a] = (counts[a] || 0) + 1);
  let topGoal = quizAnswers[0]; // fallback
  let maxCount = 0;
  for (const [goal, count] of Object.entries(counts)) {
    if (count > maxCount) {
      maxCount = count;
      topGoal = goal;
    }
  }
  
  window._preselectedGoal = topGoal;
  navigateTo('onboarding');
}

function getIconForGoal(goal) {
  const map = {
    academics: '📚',
    career: '💼',
    income: '💰',
    growth: '🌱',
    balance: '⚖️'
  };
  return map[goal] || '🎯';
}

function renderQuizText() {
  document.getElementById('quiz-title').textContent = t('quiz.title');
  document.getElementById('quiz-subtitle').textContent = t('quiz.subtitle');
  if (currentPage === 'quiz') {
    // Re-render question text if we are on the quiz page
    const qKey = `q${currentQuizQ}`;
    const el = document.getElementById('quiz-question-text');
    if(el) el.textContent = t(`quiz.${qKey}`);
    
    // Also re-render options
    document.querySelectorAll('input[name="quiz-opt"]').forEach(radio => {
      const span = radio.nextElementSibling.nextElementSibling;
      if(span) span.textContent = t(`quiz.${qKey}_${radio.value}`);
    });
    
    const nextBtn = document.getElementById('btn-quiz-next');
    if(nextBtn) nextBtn.textContent = (currentQuizQ > TOTAL_QUIZ_Q) ? t('quiz.finishBtn') : t('quiz.nextBtn');
  }
}

function initOnboarding() {
  const form = document.getElementById('onboarding-form');
  const genBtn = document.getElementById('btn-gen-alias');
  const aliasInput = document.getElementById('inp-alias');
  const studySlider = document.getElementById('inp-study-hours');
  const studyVal = document.getElementById('val-study-hours');
  const energySlider = document.getElementById('inp-energy');
  const energyVal = document.getElementById('val-energy');
  const maxHoursSlider = document.getElementById('inp-max-hours');
  const maxHoursVal = document.getElementById('val-max-hours');

  // Pre-fill if editing
  const existing = loadUser();
  if (existing) {
    aliasInput.value = existing.alias || '';
    document.getElementById('inp-semester').value = existing.semester || 3;
    studySlider.value = existing.studyHoursWeekly || 20;
    document.getElementById('inp-current-gpa').value = (existing.currentGPA !== undefined ? existing.currentGPA : 3.0).toFixed(2);
    document.getElementById('inp-target-gpa').value = (existing.targetGPA !== undefined ? existing.targetGPA : 3.5).toFixed(2);
    energySlider.value = existing.energyBaseline || 7;
    maxHoursSlider.value = existing.maxExtracurricularHours || 10;

    // Primary priority
    const priRadio = form.querySelector(`input[name="primary"][value="${existing.primaryPriority}"]`);
    if (priRadio) priRadio.checked = true;

    // Secondary goals
    (existing.secondaryGoals || []).forEach(g => {
      const chk = form.querySelector(`input[name="secondary"][value="${g}"]`);
      if (chk) chk.checked = true;
    });
  } else if (window._preselectedGoal) {
    const priRadio = form.querySelector(`input[name="primary"][value="${window._preselectedGoal}"]`);
    if (priRadio) priRadio.checked = true;
  }



  // Submit
  studySlider.addEventListener('input', () => { studyVal.textContent = studySlider.value + 'h'; });
    energySlider.addEventListener('input', () => { energyVal.textContent = energySlider.value; });
    maxHoursSlider.addEventListener('input', () => { maxHoursVal.textContent = maxHoursSlider.value + 'h'; });

    genBtn.addEventListener('click', () => {
      aliasInput.value = generateAlias();
      aliasInput.classList.add('flash');
      setTimeout(() => aliasInput.classList.remove('flash'), 300);
    });

    secCheckboxes.forEach(chk => {
      chk.addEventListener('change', () => {
        const checked = form.querySelectorAll('input[name="secondary"]:checked');
        if (checked.length > 2) {
          chk.checked = false;
        }
      });
    });

    priRadios.forEach(radio => {
      radio.addEventListener('change', () => {
        secCheckboxes.forEach(chk => {
          chk.disabled = chk.value === radio.value;
          if (chk.value === radio.value) chk.checked = false;
          chk.closest('.check-card').style.opacity = chk.disabled ? '0.4' : '1';
        });
      });
    });

    currentGpaInput.addEventListener('blur', () => formatGpa(currentGpaInput));
    targetGpaInput.addEventListener('blur', () => formatGpa(targetGpaInput));

    form.onsubmit = (e) => {
      e.preventDefault();

      const primary = form.querySelector('input[name="primary"]:checked');
      if (!primary) {
        showToast(getLang() === 'vi' ? 'Chọn ưu tiên chính' : 'Select a primary priority');
        return;
      }

      const secondary = Array.from(form.querySelectorAll('input[name="secondary"]:checked')).map(c => c.value);

      const user = {
        alias: aliasInput.value.trim() || generateAlias(),
        lang: getLang(),
        semester: parseInt(document.getElementById('inp-semester').value),
        studyHoursWeekly: parseInt(studySlider.value),
        currentGPA: parseFloat(document.getElementById('inp-current-gpa').value),
        targetGPA: parseFloat(document.getElementById('inp-target-gpa').value),
        energyBaseline: parseInt(energySlider.value),
        primaryPriority: primary.value,
        secondaryGoals: secondary,
        maxExtracurricularHours: parseInt(maxHoursSlider.value),
      };

      saveUser(user);
      recalcWeeklyLog();
      navigateTo('dashboard');
    };
}

function renderOnboardingText() {
  document.getElementById('onboarding-title').textContent = t('onboarding.title');
  document.getElementById('onboarding-subtitle').textContent = t('onboarding.subtitle');
  document.getElementById('lbl-alias').textContent = t('onboarding.aliasLabel');
  document.getElementById('inp-alias').placeholder = t('onboarding.aliasPlaceholder');
  document.getElementById('btn-gen-alias').title = t('onboarding.generateAlias');
  document.getElementById('lbl-semester').textContent = t('onboarding.semesterLabel');
  document.getElementById('lbl-study-hours').textContent = t('onboarding.studyHoursLabel');
  document.getElementById('lbl-current-gpa').textContent = t('onboarding.currentGPALabel');
  document.getElementById('lbl-target-gpa').textContent = t('onboarding.targetGPALabel');
  document.getElementById('lbl-energy').textContent = t('onboarding.energyLabel');
  document.getElementById('lbl-energy-low').textContent = t('onboarding.energyLow');
  document.getElementById('lbl-energy-high').textContent = t('onboarding.energyHigh');
  document.getElementById('lbl-primary').textContent = t('onboarding.primaryLabel');
  document.getElementById('lbl-pri-academics').textContent = t('onboarding.priorityAcademics');
  document.getElementById('lbl-pri-career').textContent = t('onboarding.priorityCareer');
  document.getElementById('lbl-pri-income').textContent = t('onboarding.priorityIncome');
  document.getElementById('lbl-pri-growth').textContent = t('onboarding.priorityGrowth');
  document.getElementById('lbl-pri-balance').textContent = t('onboarding.priorityBalance');
  document.getElementById('lbl-secondary').textContent = t('onboarding.secondaryLabel');
  document.getElementById('lbl-sec-academics').textContent = t('onboarding.priorityAcademics');
  document.getElementById('lbl-sec-career').textContent = t('onboarding.priorityCareer');
  document.getElementById('lbl-sec-income').textContent = t('onboarding.priorityIncome');
  document.getElementById('lbl-sec-growth').textContent = t('onboarding.priorityGrowth');
  document.getElementById('lbl-sec-balance').textContent = t('onboarding.priorityBalance');
  document.getElementById('lbl-max-hours').textContent = t('onboarding.maxHoursLabel');
  document.getElementById('btn-onboarding-submit').textContent = t('onboarding.submit');
}
