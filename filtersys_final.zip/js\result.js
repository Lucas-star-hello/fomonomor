// ═══════════════════════════════════════════════
// FilterSys — Analysis Result Page
// ═══════════════════════════════════════════════

let radarChartInstance = null;

function initResult() {
  const data = loadCurrentAnalysis();
  if (!data) {
    navigateTo('dashboard');
    return;
  }

  const { activity, analysis } = data;

  // Render radar chart
  renderRadarChart(analysis.scores);

  // Verdict card
  document.getElementById('result-act-name').textContent = activity.name;
  const badge = document.getElementById('result-verdict-badge');
  const verdictKey = analysis.verdict;
  const verdictText = t(`result.${verdictKey}`);
  badge.innerHTML = verdictText;
  badge.className = `verdict-badge verdict-${verdictKey}`;

  // Sections
  document.getElementById('result-opp-title').innerHTML = `📉 ${t('result.opportunityCost')}`;
  document.getElementById('result-opp-text').textContent = analysis.opportunityCost.text;

  document.getElementById('result-gpa-title').innerHTML = `📊 ${t('result.gpaRisk')}`;
  document.getElementById('result-gpa-text').textContent = analysis.gpaRisk.text;

  document.getElementById('result-energy-title').innerHTML = `🔋 ${t('result.energyBudget')}`;
  document.getElementById('result-energy-text').textContent = analysis.energyBudget.text;

  document.getElementById('result-goal-title').innerHTML = `🎯 ${t('result.goalAlignment')}`;
  document.getElementById('result-goal-text').textContent = analysis.goalAlignmentText;

  // Pros & Cons
  document.getElementById('result-pros-title').innerHTML = `✅ ${t('result.pros')}`;
  document.getElementById('result-cons-title').innerHTML = `❌ ${t('result.cons')}`;

  document.getElementById('result-pros-list').innerHTML =
    analysis.pros.map(p => `<div class="pros-item">${p}</div>`).join('') ||
    `<p class="text-muted text-sm">—</p>`;

  document.getElementById('result-cons-list').innerHTML =
    analysis.cons.map(c => `<div class="cons-item">${c}</div>`).join('') ||
    `<p class="text-muted text-sm">—</p>`;

  // Buttons
  document.getElementById('btn-commit').onclick = () => commitActivity(data.activityId);
  document.getElementById('btn-skip').onclick = () => skipActivity(data.activityId);
}

function renderRadarChart(scores) {
  const canvas = document.getElementById('radar-chart');
  const ctx = canvas.getContext('2d');

  if (radarChartInstance) {
    radarChartInstance.destroy();
  }

  const labels = [
    t('result.goalMatch'),
    t('result.energyCost'),
    t('result.timeFeasibility'),
    t('result.prosConsBalance'),
    t('result.longTermValue'),
  ];

  const data = [
    scores.goalMatch,
    scores.energyCost,
    scores.timeFeasibility,
    scores.prosCons,
    scores.longTermValue,
  ];

  radarChartInstance = new Chart(ctx, {
    type: 'radar',
    data: {
      labels,
      datasets: [{
        label: 'Score',
        data,
        backgroundColor: 'rgba(45, 212, 168, 0.15)',
        borderColor: '#2dd4a8',
        borderWidth: 2,
        pointBackgroundColor: '#2dd4a8',
        pointBorderColor: '#0a0a0f',
        pointBorderWidth: 2,
        pointRadius: 5,
        pointHoverRadius: 7,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      layout: {
        padding: 28
      },
      plugins: {
        legend: { display: false },
      },
      scales: {
        r: {
          min: 0,
          max: 10,
          ticks: {
            stepSize: 2,
            color: '#5a6378',
            backdropColor: 'transparent',
            font: { family: "'JetBrains Mono', monospace", size: 10 },
          },
          grid: {
            color: '#262640',
          },
          angleLines: {
            color: '#262640',
          },
          pointLabels: {
            color: '#8892a8',
            font: { family: "'Inter', sans-serif", size: 11, weight: '500' },
          },
        }
      },
      animation: {
        duration: 1000,
        easing: 'easeOutQuart',
      },
    }
  });
}

function commitActivity(activityId) {
  updateActivity(activityId, { status: 'committed' });

  // Update weekly log
  const acts = getCommittedActivities();
  const weekStart = getWeekStart();
  const weekActs = acts.filter(a => {
    const d = new Date(a.date);
    const ws = new Date(weekStart);
    const we = new Date(ws);
    we.setDate(we.getDate() + 7);
    return d >= ws && d < we;
  });
  const hoursUsed = weekActs.reduce((sum, a) => sum + (parseFloat(a.duration) || 0), 0);
  updateWeeklyLog({ hoursUsed, activitiesCount: weekActs.length });

  showToast(getLang() === 'vi' ? 'Đã cam kết! Hoạt động đã thêm vào lịch.' : 'Committed! Activity added to your calendar.');
  navigateTo('dashboard');
}

function skipActivity(activityId) {
  removeActivity(activityId);

  showToast(t('result.skipMsg'));
  navigateTo('dashboard');
}

function renderResultText() {
  document.getElementById('result-title').textContent = t('result.title');
  document.getElementById('result-act-label').textContent = t('result.activityName') + ':';
  document.getElementById('result-verdict-label').textContent = t('result.verdict') + ':';
  document.getElementById('btn-commit').textContent = '✓ ' + t('result.commit');
  document.getElementById('btn-skip').textContent = t('result.skipBtn');
  document.getElementById('result-commit-note').textContent = t('result.commitConfirm');
}
