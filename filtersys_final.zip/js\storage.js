// ═══════════════════════════════════════════════
// FilterSys — localStorage helpers
// ═══════════════════════════════════════════════

const STORAGE_KEYS = {
  user: 'fs_user',
  activities: 'fs_activities',
  academicTasks: 'fs_academic_tasks',
  weeklyLog: 'fs_weekly_log',
  lang: 'fs_lang',
  currentAnalysis: 'fs_current_analysis',
};

// ─── Generic helpers ───

function saveData(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

function loadData(key, fallback = null) {
  const raw = localStorage.getItem(key);
  if (!raw) return fallback;
  try { return JSON.parse(raw); }
  catch { return fallback; }
}

// ─── User Profile ───

function saveUser(user) {
  saveData(STORAGE_KEYS.user, user);
}

function loadUser() {
  return loadData(STORAGE_KEYS.user, null);
}

function hasUser() {
  return loadUser() !== null;
}

// ─── Activities ───

function saveActivities(activities) {
  saveData(STORAGE_KEYS.activities, activities);
}

function loadActivities() {
  return loadData(STORAGE_KEYS.activities, []);
}

function addActivity(activity) {
  const acts = loadActivities();
  activity.id = 'a' + Date.now();
  activity.createdAt = new Date().toISOString();
  acts.push(activity);
  saveActivities(acts);
  return activity;
}

function updateActivity(id, updates) {
  const acts = loadActivities();
  const idx = acts.findIndex(a => a.id === id);
  if (idx !== -1) {
    acts[idx] = { ...acts[idx], ...updates };
    saveActivities(acts);
  }
  return acts;
}

function removeActivity(id) {
  const acts = loadActivities().filter(a => a.id !== id);
  saveActivities(acts);
  return acts;
}

function getCommittedActivities() {
  return loadActivities().filter(a => a.status === 'committed');
}

function getActivitiesForWeek(weekStart) {
  const acts = getCommittedActivities();
  const start = new Date(weekStart);
  const end = new Date(start);
  end.setDate(end.getDate() + 7);
  return acts.filter(a => {
    const d = new Date(a.date);
    return d >= start && d < end;
  });
}

// ─── Academic Tasks ───

function saveAcademicTasks(tasks) {
  saveData(STORAGE_KEYS.academicTasks, tasks);
}

function loadAcademicTasks() {
  return loadData(STORAGE_KEYS.academicTasks, []);
}

function addAcademicTask(task) {
  const tasks = loadAcademicTasks();
  task.id = 't' + Date.now();
  task.completed = false;
  task.createdAt = new Date().toISOString();
  tasks.push(task);
  saveAcademicTasks(tasks);
  return task;
}

function toggleAcademicTask(id) {
  const tasks = loadAcademicTasks();
  const idx = tasks.findIndex(t => t.id === id);
  if (idx !== -1) {
    tasks[idx].completed = !tasks[idx].completed;
    saveAcademicTasks(tasks);
  }
  return tasks;
}

function deleteAcademicTask(id) {
  const tasks = loadAcademicTasks().filter(t => t.id !== id);
  saveAcademicTasks(tasks);
  return tasks;
}

function getUpcomingDeadlines(withinDays = 7) {
  const tasks = loadAcademicTasks();
  const now = new Date();
  const cutoff = new Date(now);
  cutoff.setDate(cutoff.getDate() + withinDays);
  return tasks.filter(t => {
    const d = new Date(t.date);
    return d >= now && d <= cutoff && !t.completed;
  }).sort((a, b) => new Date(a.date) - new Date(b.date));
}

function getExamsWithinDays(days = 3) {
  const tasks = loadAcademicTasks();
  const now = new Date();
  const cutoff = new Date(now);
  cutoff.setDate(cutoff.getDate() + days);
  return tasks.filter(t => {
    const d = new Date(t.date);
    return d >= now && d <= cutoff && t.type === 'exam';
  });
}

function getIncompleteTasksThisWeek() {
  const tasks = loadAcademicTasks();
  const now = new Date();
  const endOfWeek = new Date(now);
  endOfWeek.setDate(endOfWeek.getDate() + (7 - endOfWeek.getDay()));
  return tasks.filter(t => {
    const d = new Date(t.date);
    return d <= endOfWeek && !t.completed;
  });
}

// ─── Weekly Log ───

function getWeekKey(date = new Date()) {
  const d = new Date(date);
  const dayOfWeek = d.getDay();
  const diff = d.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1);
  const monday = new Date(d.setDate(diff));
  const year = monday.getFullYear();
  const oneJan = new Date(year, 0, 1);
  const weekNum = Math.ceil((((monday - oneJan) / 86400000) + oneJan.getDay() + 1) / 7);
  return `${year}-W${String(weekNum).padStart(2, '0')}`;
}

function getWeeklyLog() {
  const key = getWeekKey();
  const log = loadData(STORAGE_KEYS.weeklyLog, {});
  return log[key] || { hoursUsed: 0, energyCurrent: null, activitiesCount: 0 };
}

function updateWeeklyLog(updates) {
  const key = getWeekKey();
  const log = loadData(STORAGE_KEYS.weeklyLog, {});
  log[key] = { ...getWeeklyLog(), ...updates };
  saveData(STORAGE_KEYS.weeklyLog, log);
}

function recalcWeeklyLog() {
  const weekStart = getWeekStart();
  const acts = getActivitiesForWeek(weekStart);
  const hoursUsed = acts.reduce((sum, a) => sum + (parseFloat(a.duration) || 0), 0);
  const user = loadUser();
  updateWeeklyLog({
    hoursUsed,
    energyCurrent: user ? user.energyBaseline : 7,
    activitiesCount: acts.length,
  });
}

function getWeekStart(date = new Date()) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d.toISOString().split('T')[0];
}

// ─── Current Analysis (temp storage) ───

function saveCurrentAnalysis(data) {
  saveData(STORAGE_KEYS.currentAnalysis, data);
}

function loadCurrentAnalysis() {
  return loadData(STORAGE_KEYS.currentAnalysis, null);
}

// ─── Alias Generator ───

const ALIAS_ADJ = [
  'Silent', 'Quiet', 'Swift', 'Steady', 'Sharp', 'Calm', 'Bold', 'Keen',
  'Bright', 'Still', 'Clear', 'Deep', 'Iron', 'Stone', 'Frost', 'Storm',
  'Cloud', 'Sage', 'True', 'Lone', 'Dark', 'Light', 'Wild', 'Free'
];
const ALIAS_NOUN = [
  'Falcon', 'River', 'Oak', 'Wolf', 'Hawk', 'Bear', 'Fox', 'Crane',
  'Tiger', 'Eagle', 'Owl', 'Pine', 'Reed', 'Peak', 'Dawn', 'Dusk',
  'Flame', 'Wave', 'Shade', 'Star', 'Moss', 'Fern', 'Cliff', 'Ridge'
];

function generateAlias() {
  const adj = ALIAS_ADJ[Math.floor(Math.random() * ALIAS_ADJ.length)];
  const noun = ALIAS_NOUN[Math.floor(Math.random() * ALIAS_NOUN.length)];
  return `${adj} ${noun}`;
}

// ─── Motivation ───

function saveAchievements(achievements) {
  saveData('fs_achievements', achievements);
}

function loadAchievements() {
  return loadData('fs_achievements', []);
}

function addAchievement(text) {
  const achs = loadAchievements();
  const ach = {
    id: 'm' + Date.now(),
    text,
    createdAt: new Date().toISOString()
  };
  achs.push(ach);
  saveAchievements(achs);
  return ach;
}

function removeAchievement(id) {
  const achs = loadAchievements().filter(a => a.id !== id);
  saveAchievements(achs);
  return achs;
}

// ─── Courses & GPA ───

function saveCourses(courses) {
  saveData('fs_courses', courses);
}

function loadCourses() {
  return loadData('fs_courses', []);
}

function saveCPAData(data) {
  saveData('fs_cpa_data', data);
}

function loadCPAData() {
  return loadData('fs_cpa_data', { cumulativePoints: 0, cumulativeCredits: 0, retakeCredits: 0 });
}
